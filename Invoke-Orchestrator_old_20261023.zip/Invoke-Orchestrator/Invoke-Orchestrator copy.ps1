#Requires -Version 5.1

<#
.SYNOPSIS
    Runs an Orchestrator JobSpec using the Direct execution engine.

.DESCRIPTION
    Loads and validates one Orchestrator JobSpec.

    With -Preflight, checks target servers without deploying or executing
    the target script.

    Without -Preflight, deploys and executes the target script in sequential
    batches. Targets inside each batch run in parallel according to
    ThrottleLimit.

    With -ManifestPath, resumes an existing run. By default, targets with
    status Completed or CleanedUp are skipped. With -Force, all targets in
    the selected manifest are executed again.

.PARAMETER JobSpecPath
    Specifies the path to the JobSpec PSD1 file.

.PARAMETER OutputFolder
    Specifies the local output folder on the execution host.

.PARAMETER Preflight
    Performs remote readiness checks without executing the target script.

.PARAMETER ManifestPath
    Specifies an existing Orchestrator manifest to resume.

.PARAMETER Force
    Executes all targets from the selected manifest again.

.EXAMPLE
    .\Invoke-Orchestrator.ps1 `
        -JobSpecPath '.\JobSpecs\Example-Job.psd1' `
        -OutputFolder 'C:\Orchestrator-Test\Output' `
        -Preflight `
        -Verbose

.EXAMPLE
    .\Invoke-Orchestrator.ps1 `
        -JobSpecPath '.\JobSpecs\Example-Job.psd1' `
        -OutputFolder 'C:\Orchestrator-Test\Output' `
        -Confirm:$false `
        -Verbose

.EXAMPLE
    .\Invoke-Orchestrator.ps1 `
        -JobSpecPath '.\JobSpecs\Example-Job.psd1' `
        -OutputFolder 'C:\Orchestrator-Test\Output' `
        -ManifestPath 'C:\Orchestrator-Test\Output\Orchestrator_Manifest_<RunId>.csv' `
        -Confirm:$false `
        -Verbose

.EXAMPLE
    .\Invoke-Orchestrator.ps1 `
        -JobSpecPath '.\JobSpecs\Example-Job.psd1' `
        -OutputFolder 'C:\Orchestrator-Test\Output' `
        -ManifestPath 'C:\Orchestrator-Test\Output\Orchestrator_Manifest_<RunId>.csv' `
        -Force `
        -Confirm:$false `
        -Verbose

.NOTES
    Author: <name-or-team>
    Date: 2026-09-29
    Owner: <team-or-role>
    Environment: On-premises
    Domain or tenant: KNAUF.LOC / GROUP.KNAUF.LOC / TBD
    Requires: Windows PowerShell 5.1; no external modules
    Prerequisites / execution order:
        Run from the self-contained Orchestrator tool folder.
        JobSpec and referenced target script must exist.
        Direct execution requires PowerShell Remoting on target servers.
    Change reference: <TBD>
    Known limitations:
        ScheduledTask execution is not implemented in this version.
    Last reviewed: 2026-09-29
    Status: Draft – not tested
    Version: 0.3.1
    Placement: Tools
#>

[CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
param(
    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    [ValidateScript({
        if (-not (Test-Path -LiteralPath $_ -PathType Leaf)) {
            throw "JobSpec file was not found: '$_'."
        }

        if ([System.IO.Path]::GetExtension($_) -ne '.psd1') {
            throw "JobSpec must be a .psd1 file: '$_'."
        }

        $true
    })]
    [string]$JobSpecPath,

    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    [string]$OutputFolder,

    [Parameter()]
    [switch]$Preflight,

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string]$ManifestPath,

    [Parameter()]
    [switch]$Force
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

if ($Preflight -and $ManifestPath) {
    throw 'Preflight and ManifestPath cannot be used together.'
}

$ScriptRoot = Split-Path `
    -Path $MyInvocation.MyCommand.Path `
    -Parent

$ModuleRoot = Join-Path `
    -Path $ScriptRoot `
    -ChildPath 'Modules'

$CoreModulePath = Join-Path `
    -Path $ModuleRoot `
    -ChildPath 'Orchestrator.Core\Orchestrator.Core.psd1'

$ManifestModulePath = Join-Path `
    -Path $ModuleRoot `
    -ChildPath 'Orchestrator.Manifest\Orchestrator.Manifest.psd1'

$TransferModulePath = Join-Path `
    -Path $ModuleRoot `
    -ChildPath 'Orchestrator.Transfer\Orchestrator.Transfer.psd1'

$DirectModulePath = Join-Path `
    -Path $ModuleRoot `
    -ChildPath 'Orchestrator.Direct\Orchestrator.Direct.psd1'

Import-Module `
    -Name $CoreModulePath `
    -Force `
    -ErrorAction Stop

Import-Module `
    -Name $ManifestModulePath `
    -Force `
    -ErrorAction Stop

Import-Module `
    -Name $TransferModulePath `
    -Force `
    -ErrorAction Stop

Import-Module `
    -Name $DirectModulePath `
    -Force `
    -ErrorAction Stop

try {
    $ResolvedJobSpecPath = (
        Resolve-Path `
            -LiteralPath $JobSpecPath `
            -ErrorAction Stop
    ).ProviderPath

    $JobSpec = Import-OrchestratorJobSpec `
        -Path $ResolvedJobSpecPath

    if ($JobSpec.ExecutionEngine -ne 'Direct') {
        throw "ExecutionEngine '$($JobSpec.ExecutionEngine)' is not implemented in this version."
    }

    if ([System.IO.Path]::IsPathRooted($OutputFolder)) {
        $ResolvedOutputFolder = [System.IO.Path]::GetFullPath(
            $OutputFolder
        )
    }
    else {
        $ResolvedOutputFolder = [System.IO.Path]::GetFullPath(
            (Join-Path `
                -Path (Get-Location).ProviderPath `
                -ChildPath $OutputFolder)
        )
    }

    if (-not (Test-Path `
        -LiteralPath $ResolvedOutputFolder `
        -PathType Container)) {

        if ($PSCmdlet.ShouldProcess(
            $ResolvedOutputFolder,
            'Create local output folder'
        )) {
            New-Item `
                -Path $ResolvedOutputFolder `
                -ItemType Directory `
                -Force `
                -ErrorAction Stop | Out-Null
        }
    }

    if ($Preflight) {
        $RunId = New-OrchestratorRunId

        $PreflightPath = Join-Path `
            -Path $ResolvedOutputFolder `
            -ChildPath "Orchestrator_Preflight_$RunId.csv"

        $PreflightResults = @(
            Test-OrchestratorPreflight `
                -Target $JobSpec.Targets `
                -RemoteFolder $JobSpec.RemoteFolder `
                -WhatIf:$WhatIfPreference
        )

        if (-not $WhatIfPreference) {
            $PreflightResults |
                Export-Csv `
                    -Path $PreflightPath `
                    -NoTypeInformation `
                    -Encoding UTF8 `
                    -Force `
                    -ErrorAction Stop
        }

        $PreflightResults
        return
    }

    $IsResume = -not [string]::IsNullOrWhiteSpace($ManifestPath)

    if ($IsResume) {
        $ResolvedManifestPath = (
            Resolve-Path `
                -LiteralPath $ManifestPath `
                -ErrorAction Stop
        ).ProviderPath

        $ManifestRows = @(
            Import-Csv `
                -LiteralPath $ResolvedManifestPath `
                -ErrorAction Stop
        )

        if ($ManifestRows.Count -eq 0) {
            throw "Manifest contains no rows: '$ResolvedManifestPath'."
        }

        $ManifestColumns = @(
            $ManifestRows[0].PSObject.Properties.Name
        )

        foreach ($RequiredColumn in @(
            'RunId',
            'JobName',
            'Target',
            'Status',
            'ExecutionEngine'
        )) {
            if ($RequiredColumn -notin $ManifestColumns) {
                throw "Manifest is missing required column '$RequiredColumn'."
            }
        }

        $InvalidJobRows = @(
            $ManifestRows |
                Where-Object {
                    $_.JobName -ne $JobSpec.JobName
                }
        )

        if ($InvalidJobRows.Count -gt 0) {
            throw 'Manifest JobName does not match the selected JobSpec.'
        }

        $InvalidEngineRows = @(
            $ManifestRows |
                Where-Object {
                    $_.ExecutionEngine -ne $JobSpec.ExecutionEngine
                }
        )

        if ($InvalidEngineRows.Count -gt 0) {
            throw 'Manifest ExecutionEngine does not match the selected JobSpec.'
        }

        $RunId = [string]$ManifestRows[0].RunId
        $ResolvedManifestPath = (
            Resolve-Path `
                -LiteralPath $ResolvedManifestPath `
                -ErrorAction Stop
        ).ProviderPath

        $ManifestPath = $ResolvedManifestPath

        if ($Force) {
            $TargetsToRun = @(
                $ManifestRows |
                    Select-Object -ExpandProperty Target
            )
        }
        else {
            $TargetsToRun = @(
                $ManifestRows |
                    Where-Object {
                        $_.Status -notin @(
                            'Completed',
                            'CleanedUp'
                        )
                    } |
                    Select-Object -ExpandProperty Target
            )
        }

        Write-Verbose (
            "Manifest resume selected $($TargetsToRun.Count) target(s)."
        )
    }
    else {
        $RunId = New-OrchestratorRunId

        $ManifestPath = Join-Path `
            -Path $ResolvedOutputFolder `
            -ChildPath "Orchestrator_Manifest_$RunId.csv"

        $ManifestRows = @(
            foreach ($Target in $JobSpec.Targets) {
                New-OrchestratorManifestRow `
                    -RunId $RunId `
                    -JobName $JobSpec.JobName `
                    -Target $Target `
                    -ExecutionEngine $JobSpec.ExecutionEngine `
                    -RemoteFolder $JobSpec.RemoteFolder `
                    -InitialStatus 'Pending'
            }
        )

        $TargetsToRun = @($JobSpec.Targets)

        if ($PSCmdlet.ShouldProcess(
            $ManifestPath,
            'Create the initial Orchestrator manifest'
        )) {
            Save-OrchestratorManifest `
                -Rows $ManifestRows `
                -Path $ManifestPath
        }
    }

    if ($TargetsToRun.Count -eq 0) {
        Write-Verbose 'No targets require execution.'
        $ManifestRows
        return
    }

    $ExecutionResults = @()
    $BatchSize = [Math]::Max(1, $JobSpec.ThrottleLimit)
    $BatchNumber = 0

    for (
        $Index = 0;
        $Index -lt $TargetsToRun.Count;
        $Index += $BatchSize
    ) {
        $BatchNumber++

        $LastIndex = [Math]::Min(
            $Index + $BatchSize - 1,
            $TargetsToRun.Count - 1
        )

        $BatchTargets = @(
            $TargetsToRun[$Index..$LastIndex]
        )

        Write-Verbose (
            "Starting batch $BatchNumber with $($BatchTargets.Count) target(s)."
        )

        $BatchJobs = @()

        foreach ($Target in $BatchTargets) {
            $ManifestRow = @(
                $ManifestRows |
                    Where-Object {
                        $_.Target -eq $Target
                    }
            )[0]

            if ($null -eq $ManifestRow) {
                throw "Manifest row was not found for target '$Target'."
            }

            if (-not $PSCmdlet.ShouldProcess(
                $Target,
                'Deploy, run, collect results, and clean up through Direct execution'
            )) {
                $ManifestRow.Status = 'Skipped'
                $ManifestRow.Stage = 'WhatIf'
                $ManifestRow.CleanupStatus = 'NotPerformed'
                $ManifestRow.ErrorMessage = 'No change was performed because WhatIf was used.'

                continue
            }

            $ManifestRow.Status = 'Running'
            $ManifestRow.Stage = 'Run'
            $ManifestRow.StartedUtc = (
                Get-Date
            ).ToUniversalTime().ToString('o')

            $BatchJobs += Start-Job `
                -Name "Orchestrator_$Target" `
                -ScriptBlock {
                    param(
                        [string]$ModulePath,
                        [string]$ComputerName,
                        [string]$TargetScriptPath,
                        [hashtable]$TargetParameters,
                        [string]$TargetRemoteFolder,
                        [int]$TargetTimeoutMinutes,
                        [string]$TargetOutputFolder,
                        [string]$TargetCleanupMode,
                        [bool]$UseVerbose
                    )

                    Set-StrictMode -Version Latest
                    $ErrorActionPreference = 'Stop'

                    Import-Module `
                        -Name $ModulePath `
                        -Force `
                        -ErrorAction Stop

                    Invoke-OrchestratorDirect `
                        -Target $ComputerName `
                        -ScriptPath $TargetScriptPath `
                        -Parameters $TargetParameters `
                        -RemoteFolder $TargetRemoteFolder `
                        -TimeoutMinutes $TargetTimeoutMinutes `
                        -OutputFolder $TargetOutputFolder `
                        -CleanupMode $TargetCleanupMode `
                        -Confirm:$false `
                        -Verbose:$UseVerbose
                } `
                -ArgumentList @(
                    $DirectModulePath,
                    $Target,
                    $JobSpec.ScriptPath,
                    $JobSpec.Parameters,
                    $JobSpec.RemoteFolder,
                    $JobSpec.TimeoutMinutes,
                    $ResolvedOutputFolder,
                    $JobSpec.CleanupMode,
                    [bool]$VerbosePreference
                )
        }

        if (-not $WhatIfPreference) {
            Save-OrchestratorManifest `
                -Rows $ManifestRows `
                -Path $ManifestPath
        }

        if ($BatchJobs.Count -eq 0) {
            continue
        }

        Write-Verbose "Waiting for batch $BatchNumber to finish."

        Wait-Job `
            -Job $BatchJobs `
            -ErrorAction Stop | Out-Null

        foreach ($BatchJob in $BatchJobs) {
            $Target = $BatchJob.Name -replace '^Orchestrator_', ''

            try {
                if ($BatchJob.State -eq 'Failed') {
                    $JobError = Receive-Job `
                        -Job $BatchJob `
                        -ErrorAction SilentlyContinue 2>&1 |
                        Out-String

                    throw "Background job failed. $JobError"
                }

                $ExecutionResult = @(
                    Receive-Job `
                        -Job $BatchJob `
                        -ErrorAction Stop
                ) |
                    Where-Object {
                        $_.PSObject.Properties.Name -contains 'Status'
                    } |
                    Select-Object -Last 1

                if ($null -eq $ExecutionResult) {
                    throw 'Background job did not return an execution result.'
                }
            }
            catch {
                $ExecutionResult = [pscustomobject]@{
                    Target          = $Target
                    RunId           = ''
                    Status          = 'Failed'
                    Stage           = 'Run'
                    RemoteRunFolder = ''
                    OutputFolder    = ''
                    ResultFile      = ''
                    OutputFiles     = ''
                    CleanupStatus   = 'NotPerformed'
                    ErrorMessage    = $_.Exception.Message
                    StartedUtc      = ''
                    FinishedUtc     = (
                        Get-Date
                    ).ToUniversalTime().ToString('o')
                }
            }
            finally {
                Remove-Job `
                    -Job $BatchJob `
                    -Force `
                    -ErrorAction SilentlyContinue
            }

            $ExecutionResults += $ExecutionResult

            $ManifestRow = @(
                $ManifestRows |
                    Where-Object {
                        $_.Target -eq $ExecutionResult.Target
                    }
            )[0]

            if ($null -eq $ManifestRow) {
                throw "Manifest row was not found for target '$($ExecutionResult.Target)'."
            }

            $ManifestRow.Status = $ExecutionResult.Status
            $ManifestRow.Stage = $ExecutionResult.Stage
            $ManifestRow.RemoteRunFolder = $ExecutionResult.RemoteRunFolder
            $ManifestRow.StartedUtc = $ExecutionResult.StartedUtc
            $ManifestRow.FinishedUtc = $ExecutionResult.FinishedUtc
            $ManifestRow.ResultFile = $ExecutionResult.ResultFile
            $ManifestRow.OutputFiles = $ExecutionResult.OutputFiles
            $ManifestRow.CleanupStatus = $ExecutionResult.CleanupStatus
            $ManifestRow.ErrorMessage = $ExecutionResult.ErrorMessage

            Save-OrchestratorManifest `
                -Rows $ManifestRows `
                -Path $ManifestPath
        }

        Write-Verbose (
            "Batch $BatchNumber completed. Manifest checkpoint saved."
        )
    }

    $ExecutionResultsPath = Join-Path `
        -Path $ResolvedOutputFolder `
        -ChildPath "Orchestrator_ExecutionResults_$RunId.csv"

    $ExecutionResults |
        Export-Csv `
            -Path $ExecutionResultsPath `
            -NoTypeInformation `
            -Encoding UTF8 `
            -Force `
            -ErrorAction Stop

    $ExecutionResults
}
catch {
    throw "Orchestrator operation failed. Error: $($_.Exception.Message)"
}