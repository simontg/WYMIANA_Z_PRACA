@{
    JobName = 'DRIsolation-ProductionHost'

    ScriptPath = '..\TargetScripts\Test-DRIsolation-ProductionHost.ps1'

    Targets = @(
        'CAZ-WEU-DC06',
        'DE-IPH-DC23'
    )

    Parameters = @{
        TargetIP        = '<IP-SERWERA-Z-LISTENEREM>'
        Role            = 'DomainController'
        Method          = 'Socket'
        TraceRoute      = $true
        TimeoutMs       = 1500
        FastFailSeconds = 3.0
        PacketsPerPort  = 5
    }

    ExecutionEngine = 'Direct'
    RemoteFolder    = 'C:\temp'
    ThrottleLimit   = 10
    TimeoutMinutes  = 30
    OutputFolder    = 'C:\Users\T0_GmerekS\TOOLS\Orchestrator-DRIsolation\Output'
    CleanupMode     = 'OnSuccess'
}