@{
    JobName = 'Example-Orchestrator-Job'

    ScriptPath = '..\TargetScripts\Test-Example.ps1'

    Targets = @(
        'CAZ-WEU-DC06',
        'DE-IPH-DC23'
    )

    Parameters = @{
        ExampleValue = 'Test'
        Count        = 1
        Force        = $false
    }

    ExecutionEngine = 'Direct'
    RemoteFolder    = 'C:\temp'
    ThrottleLimit   = 10
    TimeoutMinutes  = 15
    OutputFolder    = 'C:\Orchestrator\Output'
    CleanupMode     = 'OnSuccess'
}