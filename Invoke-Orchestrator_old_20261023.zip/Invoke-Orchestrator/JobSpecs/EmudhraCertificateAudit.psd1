@{
    JobName = 'EmudhraCertificateAudit'

    ScriptPath = '..\TargetScripts\Invoke-EmudhraCertificateAudit.ps1'

    Targets = @(
       
    'CAZ-WEU-DC05.KNAUF.LOC',
'DE-HUE-DC02.GROUP.KNAUF.LOC',
'DE-IPH-DC22.GROUP.KNAUF.LOC',
'de-iph-dc18.GROUP.KNAUF.LOC',
'de-iph-dc24.GROUP.KNAUF.LOC',
'caz-brs-dc02.GROUP.KNAUF.LOC',
'CAZ-USC-DC02.GROUP.KNAUF.LOC',
'US-SBV-DC10.GROUP.KNAUF.LOC',
'CAZ-GWC-DC02.GROUP.KNAUF.LOC',
'CAZ-AUE-DC06.GROUP.KNAUF.LOC',
'CAZ-WEU-ADTOOL.KNAUF.LOC',
'CAZ-WEU-AGPM01.KNAUF.LOC',
'caz-weu-admon01.KNAUF.LOC',
'CAZ-WEU-T0SIA01.KNAUF.LOC',
'CAZ-SEA-DC11.KNAUF.LOC',
'de-iph-adbkp01.KNAUF.LOC',
'CAZ-GWC-NDES01.KNAUF.LOC',
'CAZ-GWC-NDES03.KNAUF.LOC',
'CAZ-GWC-NDES02.KNAUF.LOC',
'CAZ-GWC-NDES05.KNAUF.LOC',
'CAZ-GWC-NDES04.KNAUF.LOC',
'CAZ-WEU-T0WU01.KNAUF.LOC',
'de-iph-ca10.KNAUF.LOC',
'CAZ-WEU-T0TL01.KNAUF.LOC',
'de-iph-dc20.GROUP.KNAUF.LOC',
'CAZ-WEU-AAD02.KNAUF.LOC',
'US-SBV-DC08.GROUP.KNAUF.LOC',
'CAZ-WEU-DC10.GROUP.KNAUF.LOC',
'CAZ-AUE-DC03.KNAUF.LOC',
'CAZ-WEU-DC07.KNAUF.LOC',
'CAZ-SEA-DC07.KNAUF.LOC',
'CAZ-WEU-DC09.KNAUF.LOC',
'US-SBV-DC07.KNAUF.LOC',
'DE-IPH-DC29.KNAUF.LOC',
'de-iph-dc17.KNAUF.LOC',
'de-iph-dc23.KNAUF.LOC',
'DE-IPH-DC21.KNAUF.LOC',
'caz-brs-dc01.KNAUF.LOC',
'de-iph-dc19.KNAUF.LOC',
'US-SBV-DC09.KNAUF.LOC',
'AR-BUE-DC07.KNAUF.LOC',
'CAZ-USC-DC01.KNAUF.LOC',
'CAZ-SEA-DC05.KNAUF.LOC',
'CAZ-GWC-DC01.KNAUF.LOC',
'CAZ-AUE-DC05.KNAUF.LOC',
'CAZ-SEA-DC09.KNAUF.LOC',
'CAZ-WEU-DC06.GROUP.KNAUF.LOC',
'CAZ-WEU-DC08.GROUP.KNAUF.LOC',
'CAZ-AUE-DC04.GROUP.KNAUF.LOC',
'CAZ-SEA-DC06.GROUP.KNAUF.LOC',
'CAZ-SEA-DC08.GROUP.KNAUF.LOC',
'AR-BUE-DC08.GROUP.KNAUF.LOC',
'de-iph-aad01.KNAUF.LOC'
    
    
    
        <#
        'SERVER01',
        'SERVER02',
        'SERVER03'
        #>
    )

    Parameters = @{
    }

    ExecutionEngine = 'Direct'
    RemoteFolder    = 'C:\temp'
    ThrottleLimit   = 10
    TimeoutMinutes  = 30
    OutputFolder    = 'C:\Users\T0_GmerekS\TOOLS\Orchestrator-EmudhraAudit\Output'
    CleanupMode     = 'OnSuccess'
}