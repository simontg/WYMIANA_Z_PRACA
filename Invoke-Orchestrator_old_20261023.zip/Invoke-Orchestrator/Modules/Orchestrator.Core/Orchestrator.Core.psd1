@{
    RootModule        = 'Orchestrator.Core.psm1'
    ModuleVersion     = '0.1.0'
    GUID              = '4f77f52c-9d08-4cbb-8fa3-3b3fa71e7d41'
    Author            = '<name-or-team>'
    CompanyName       = 'Knauf'
    Copyright         = '(c) Knauf. All rights reserved.'
    PowerShellVersion = '5.1'

    FunctionsToExport = @(
        'Import-OrchestratorJobSpec',
        'New-OrchestratorRunId'
    )

    VariablesToExport = @()
    AliasesToExport   = @()
}