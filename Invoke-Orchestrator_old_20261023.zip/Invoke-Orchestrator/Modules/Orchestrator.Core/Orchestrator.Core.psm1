Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function New-OrchestratorRunId {
    [CmdletBinding()]
    param()

    $UtcNow = (Get-Date).ToUniversalTime()
    $Timestamp = $UtcNow.ToString('yyyyMMdd_HHmmss')
    $RandomPart = [System.Guid]::NewGuid().ToString('N').Substring(0, 8)

    return "ORC_${Timestamp}_$RandomPart"
}

function Import-OrchestratorJobSpec {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$Path
    )

    $ResolvedPath = (
        Resolve-Path `
            -LiteralPath $Path `
            -ErrorAction Stop
    ).ProviderPath

    $RawJobSpec = Import-PowerShellDataFile `
        -LiteralPath $ResolvedPath

    if ($null -eq $RawJobSpec) {
        throw "JobSpec is empty: '$ResolvedPath'."
    }

    $RequiredProperties = @(
        'JobName',
        'ScriptPath',
        'Targets',
        'Parameters',
        'ExecutionEngine',
        'RemoteFolder',
        'ThrottleLimit',
        'TimeoutMinutes',
        'OutputFolder',
        'CleanupMode'
    )

    foreach ($PropertyName in $RequiredProperties) {
        if (-not $RawJobSpec.ContainsKey($PropertyName)) {
            throw "JobSpec is missing required property '$PropertyName'."
        }
    }

    if ([string]::IsNullOrWhiteSpace(
        [string]$RawJobSpec.JobName
    )) {
        throw 'JobSpec JobName cannot be empty.'
    }

    if ([string]::IsNullOrWhiteSpace(
        [string]$RawJobSpec.ScriptPath
    )) {
        throw 'JobSpec ScriptPath cannot be empty.'
    }

    $JobSpecFolder = Split-Path `
        -Path $ResolvedPath `
        -Parent

    $ScriptPath = [string]$RawJobSpec.ScriptPath

    if (-not [System.IO.Path]::IsPathRooted($ScriptPath)) {
        $ScriptPath = Join-Path `
            -Path $JobSpecFolder `
            -ChildPath $ScriptPath
    }

    $ScriptPath = [System.IO.Path]::GetFullPath($ScriptPath)

    if (-not (Test-Path `
        -LiteralPath $ScriptPath `
        -PathType Leaf)) {

        throw "ScriptPath was not found: '$ScriptPath'."
    }

    if ([System.IO.Path]::GetExtension($ScriptPath) -ne '.ps1') {
        throw "ScriptPath must point to a PowerShell script: '$ScriptPath'."
    }

    $Targets = @($RawJobSpec.Targets)

    if ($Targets.Count -eq 0) {
        throw 'JobSpec must contain at least one target.'
    }

    foreach ($Target in $Targets) {
        if ([string]::IsNullOrWhiteSpace([string]$Target)) {
            throw 'JobSpec contains an empty target.'
        }
    }

    $ExecutionEngine = [string]$RawJobSpec.ExecutionEngine

    if (@('Direct', 'ScheduledTask') -notcontains $ExecutionEngine) {
        throw "ExecutionEngine must be 'Direct' or 'ScheduledTask'."
    }

    $ThrottleLimit = 0

    if (-not [int]::TryParse(
        [string]$RawJobSpec.ThrottleLimit,
        [ref]$ThrottleLimit
    )) {
        throw 'ThrottleLimit must be an integer.'
    }

    if ($ThrottleLimit -lt 1 -or $ThrottleLimit -gt 50) {
        throw 'ThrottleLimit must be between 1 and 50.'
    }

    $TimeoutMinutes = 0

    if (-not [int]::TryParse(
        [string]$RawJobSpec.TimeoutMinutes,
        [ref]$TimeoutMinutes
    )) {
        throw 'TimeoutMinutes must be an integer.'
    }

    if ($TimeoutMinutes -lt 1) {
        throw 'TimeoutMinutes must be at least 1.'
    }

    $RemoteFolder = [string]$RawJobSpec.RemoteFolder

    if ([string]::IsNullOrWhiteSpace($RemoteFolder)) {
        throw 'RemoteFolder cannot be empty.'
    }

    $CleanupMode = [string]$RawJobSpec.CleanupMode

    if (@('OnSuccess', 'Always', 'Never') -notcontains $CleanupMode) {
        throw "CleanupMode must be 'OnSuccess', 'Always', or 'Never'."
    }

    if ($RawJobSpec.Parameters -isnot [hashtable]) {
        throw 'Parameters must be a PowerShell hashtable.'
    }

    [pscustomobject]@{
        JobName         = [string]$RawJobSpec.JobName
        ScriptPath      = $ScriptPath
        Targets         = $Targets
        Parameters      = $RawJobSpec.Parameters
        ExecutionEngine = $ExecutionEngine
        RemoteFolder    = $RemoteFolder
        ThrottleLimit   = $ThrottleLimit
        TimeoutMinutes  = $TimeoutMinutes
        OutputFolder    = [string]$RawJobSpec.OutputFolder
        CleanupMode     = $CleanupMode
        JobSpecPath     = $ResolvedPath
    }
}

Export-ModuleMember -Function @(
    'Import-OrchestratorJobSpec',
    'New-OrchestratorRunId'
)