@{
    RootModule        = 'Orchestrator.Transfer.psm1'
    ModuleVersion     = '0.1.0'
    GUID              = '2e6c8c1e-2b0e-4aa9-8f76-67a45d07a8a1'
    Author            = '<name-or-team>'
    CompanyName       = 'Knauf'
    Copyright         = '(c) Knauf. All rights reserved.'
    PowerShellVersion = '5.1'

    FunctionsToExport = @(
        'Test-OrchestratorPreflight'
    )

    VariablesToExport = @()
    AliasesToExport   = @()
}