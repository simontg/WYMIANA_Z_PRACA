Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Test-OrchestratorPreflight {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string[]]$Target,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$RemoteFolder,

        [Parameter()]
        [switch]$WhatIf
    )

    foreach ($ComputerName in $Target) {
        $StartedUtc = (Get-Date).ToUniversalTime()
        $Session = $null
        $TestFolder = Join-Path `
            -Path $RemoteFolder `
            -ChildPath ("Orchestrator_Preflight_{0}" -f (
                [Guid]::NewGuid().ToString('N')
            ))

        try {
            Test-WSMan `
                -ComputerName $ComputerName `
                -ErrorAction Stop | Out-Null

            if ($WhatIf) {
                [pscustomobject]@{
                    Target              = $ComputerName
                    Status              = 'ReadyForExecutionPlan'
                    WinRM               = 'Not tested'
                    PSSession           = 'Not tested'
                    RemoteFolderAccess  = 'Not tested'
                    TestFolder          = $TestFolder
                    ErrorMessage        = ''
                    StartedUtc          = $StartedUtc.ToString('o')
                    FinishedUtc         = (Get-Date).ToUniversalTime().ToString('o')
                }

                continue
            }

            $Session = New-PSSession `
                -ComputerName $ComputerName `
                -ErrorAction Stop

            Invoke-Command `
                -Session $Session `
                -ScriptBlock {
                    param(
                        [string]$Path
                    )

                    New-Item `
                        -Path $Path `
                        -ItemType Directory `
                        -Force `
                        -ErrorAction Stop | Out-Null

                    if (-not (Test-Path `
                        -LiteralPath $Path `
                        -PathType Container)) {

                        throw "Test folder was not created: '$Path'."
                    }

                    Remove-Item `
                        -LiteralPath $Path `
                        -Force `
                        -Recurse `
                        -ErrorAction Stop
                } `
                -ArgumentList $TestFolder `
                -ErrorAction Stop

            [pscustomobject]@{
                Target              = $ComputerName
                Status              = 'Ready'
                WinRM               = 'Passed'
                PSSession           = 'Passed'
                RemoteFolderAccess  = 'Passed'
                TestFolder          = $TestFolder
                ErrorMessage        = ''
                StartedUtc          = $StartedUtc.ToString('o')
                FinishedUtc         = (Get-Date).ToUniversalTime().ToString('o')
            }
        }
        catch {
            [pscustomobject]@{
                Target              = $ComputerName
                Status              = 'Failed'
                WinRM               = 'Failed or not verified'
                PSSession           = 'Failed or not verified'
                RemoteFolderAccess  = 'Failed or not verified'
                TestFolder          = $TestFolder
                ErrorMessage        = $_.Exception.Message
                StartedUtc          = $StartedUtc.ToString('o')
                FinishedUtc          = (Get-Date).ToUniversalTime().ToString('o')
            }
        }
        finally {
            if ($null -ne $Session) {
                Remove-PSSession `
                    -Session $Session `
                    -ErrorAction SilentlyContinue
            }
        }
    }
}

Export-ModuleMember -Function 'Test-OrchestratorPreflight'