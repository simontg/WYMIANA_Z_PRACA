Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Invoke-OrchestratorDirect {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    param(
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$Target,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$ScriptPath,

        [Parameter(Mandatory)]
        [hashtable]$Parameters,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$RemoteFolder,

        [Parameter(Mandatory)]
        [ValidateRange(1, 1440)]
        [int]$TimeoutMinutes,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$OutputFolder,

        [Parameter(Mandatory)]
        [ValidateSet('OnSuccess', 'Always', 'Never')]
        [string]$CleanupMode
    )

    $StartedUtc = (Get-Date).ToUniversalTime()
    $Session = $null
    $Job = $null

    $SafeTarget = $Target -replace '[^a-zA-Z0-9._-]', '_'
    $RunId = 'ORC_{0}_{1}' -f (
        $StartedUtc.ToString('yyyyMMdd_HHmmss'),
        [System.Guid]::NewGuid().ToString('N').Substring(0, 8)
    )

    $RemoteRunFolder = Join-Path `
        -Path $RemoteFolder `
        -ChildPath "${RunId}_${SafeTarget}"

    $RemoteScriptFile = Join-Path `
        -Path $RemoteRunFolder `
        -ChildPath (Split-Path -Path $ScriptPath -Leaf)

    $LocalTargetOutputFolder = Join-Path `
        -Path $OutputFolder `
        -ChildPath $SafeTarget

    $Result = [ordered]@{
        Target          = $Target
        RunId           = $RunId
        Status          = 'Failed'
        Stage           = 'Preparation'
        RemoteRunFolder = $RemoteRunFolder
        OutputFolder    = $LocalTargetOutputFolder
        ResultFile      = ''
        OutputFiles     = ''
        CleanupStatus   = 'NotStarted'
        ErrorMessage    = ''
        StartedUtc      = $StartedUtc.ToString('o')
        FinishedUtc     = ''
    }

    try {
        Write-Verbose "Creating PowerShell Remoting session to '$Target'."

        $Session = New-PSSession `
            -ComputerName $Target `
            -ErrorAction Stop

        if (-not $PSCmdlet.ShouldProcess(
            $Target,
            "Create remote work folder '$RemoteRunFolder' and deploy '$RemoteScriptFile'"
        )) {
            $Result.Status = 'WhatIf'
            $Result.Stage = 'Deploy'
            return [pscustomobject]$Result
        }

        Invoke-Command `
            -Session $Session `
            -ScriptBlock {
                param(
                    [string]$Path
                )

                if (Test-Path -LiteralPath $Path) {
                    throw "Remote run folder already exists: '$Path'."
                }

                New-Item `
                    -Path $Path `
                    -ItemType Directory `
                    -Force `
                    -ErrorAction Stop | Out-Null
            } `
            -ArgumentList $RemoteRunFolder `
            -ErrorAction Stop

        Copy-Item `
            -Path $ScriptPath `
            -Destination $RemoteRunFolder `
            -ToSession $Session `
            -Force `
            -ErrorAction Stop

        $Result.Stage = 'Run'

        if (-not $PSCmdlet.ShouldProcess(
            $Target,
            "Run '$RemoteScriptFile' through PowerShell Remoting"
        )) {
            $Result.Status = 'WhatIf'
            return [pscustomobject]$Result
        }

        $Job = Invoke-Command `
            -Session $Session `
            -AsJob `
            -ScriptBlock {
                param(
                    [string]$ScriptFile,
                    [hashtable]$ScriptParameters
                )

                & $ScriptFile @ScriptParameters
            } `
            -ArgumentList $RemoteScriptFile, $Parameters `
            -ErrorAction Stop

        $Completed = Wait-Job `
            -Job $Job `
            -Timeout ($TimeoutMinutes * 60) `
            -ErrorAction Stop

        if ($null -eq $Completed) {
            $Result.Status = 'Stopped'
            $Result.Stage = 'Run'
            $Result.ErrorMessage = "Timeout exceeded: $TimeoutMinutes minute(s)."
            return [pscustomobject]$Result
        }

        if ($Job.State -ne 'Completed') {
            $JobError = Receive-Job `
                -Job $Job `
                -ErrorAction SilentlyContinue 2>&1 |
                Out-String

            throw "Remote job ended in state '$($Job.State)'. $JobError"
        }

        Receive-Job `
            -Job $Job `
            -ErrorAction SilentlyContinue |
            Out-Null

        $Result.Stage = 'Collect'

        $RemoteContractPath = Join-Path `
            -Path $RemoteRunFolder `
            -ChildPath '_result.json'

        $ContractText = Invoke-Command `
            -Session $Session `
            -ScriptBlock {
                param(
                    [string]$Path
                )

                if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
                    return $null
                }

                Get-Content `
                    -LiteralPath $Path `
                    -Raw `
                    -ErrorAction Stop
            } `
            -ArgumentList $RemoteContractPath `
            -ErrorAction Stop

        if ([string]::IsNullOrWhiteSpace($ContractText)) {
            $Result.Status = 'ContractMissing'
            $Result.ErrorMessage = "Result contract was not found: '$RemoteContractPath'."
            return [pscustomobject]$Result
        }

        try {
            $Contract = $ContractText | ConvertFrom-Json -ErrorAction Stop
        }
        catch {
            $Result.Status = 'ContractMissing'
            $Result.ErrorMessage = "Result contract is not valid JSON. Error: $($_.Exception.Message)"
            return [pscustomobject]$Result
        }

        if ($null -eq $Contract.Success -or
            $null -eq $Contract.OutputFiles) {

            $Result.Status = 'ContractMissing'
            $Result.ErrorMessage = 'Result contract does not contain Success and OutputFiles.'
            return [pscustomobject]$Result
        }

        if (-not (Test-Path -LiteralPath $LocalTargetOutputFolder -PathType Container)) {
            New-Item `
                -Path $LocalTargetOutputFolder `
                -ItemType Directory `
                -Force `
                -ErrorAction Stop | Out-Null
        }

        Copy-Item `
            -Path $RemoteContractPath `
            -Destination $LocalTargetOutputFolder `
            -FromSession $Session `
            -Force `
            -ErrorAction Stop

        $CopiedFiles = @('_result.json')

        foreach ($OutputFile in @($Contract.OutputFiles)) {
            $OutputFileName = [string]$OutputFile

            if ([string]::IsNullOrWhiteSpace($OutputFileName) -or
                [System.IO.Path]::IsPathRooted($OutputFileName) -or
                $OutputFileName.Contains('..') -or
                $OutputFileName.Contains('\') -or
                $OutputFileName.Contains('/')) {

                throw "Result contract contains an invalid output file name: '$OutputFileName'."
            }

            $RemoteOutputFile = Join-Path `
                -Path $RemoteRunFolder `
                -ChildPath $OutputFileName

            $RemoteFileExists = Invoke-Command `
                -Session $Session `
                -ScriptBlock {
                    param(
                        [string]$Path
                    )

                    Test-Path `
                        -LiteralPath $Path `
                        -PathType Leaf
                } `
                -ArgumentList $RemoteOutputFile `
                -ErrorAction Stop

            if (-not $RemoteFileExists) {
                throw "Output file listed in result contract was not found: '$RemoteOutputFile'."
            }

            Copy-Item `
                -Path $RemoteOutputFile `
                -Destination $LocalTargetOutputFolder `
                -FromSession $Session `
                -Force `
                -ErrorAction Stop

            $CopiedFiles += $OutputFileName
        }

        $Result.ResultFile = Join-Path `
            -Path $LocalTargetOutputFolder `
            -ChildPath '_result.json'

        $Result.OutputFiles = $CopiedFiles -join ';'

        if ([bool]$Contract.Success) {
            $Result.Status = 'Completed'
        }
        else {
            $Result.Status = 'Failed'
            $Result.ErrorMessage = [string]$Contract.Error
        }

        $RemoveRemoteFolder = $false

        if ($CleanupMode -eq 'Always') {
            $RemoveRemoteFolder = $true
        }
        elseif ($CleanupMode -eq 'OnSuccess' -and $Result.Status -eq 'Completed') {
            $RemoveRemoteFolder = $true
        }

        if ($RemoveRemoteFolder) {
            $Result.Stage = 'Cleanup'

            if ($PSCmdlet.ShouldProcess(
                $Target,
                "Remove remote run folder '$RemoteRunFolder'"
            )) {
                Invoke-Command `
                    -Session $Session `
                    -ScriptBlock {
                        param(
                            [string]$Path
                        )

                        Remove-Item `
                            -LiteralPath $Path `
                            -Recurse `
                            -Force `
                            -ErrorAction Stop
                    } `
                    -ArgumentList $RemoteRunFolder `
                    -ErrorAction Stop

                $Result.CleanupStatus = 'Completed'
            }
        }
        else {
            $Result.CleanupStatus = 'NotPerformed'
        }
    }
    catch {
        $Result.Status = 'Failed'
        $Result.ErrorMessage = $_.Exception.Message
    }
    finally {
        if ($null -ne $Job) {
            Remove-Job `
                -Job $Job `
                -Force `
                -ErrorAction SilentlyContinue
        }

        if ($null -ne $Session) {
            Remove-PSSession `
                -Session $Session `
                -ErrorAction SilentlyContinue
        }

        $Result.FinishedUtc = (Get-Date).ToUniversalTime().ToString('o')
    }

    return [pscustomobject]$Result
}

Export-ModuleMember -Function 'Invoke-OrchestratorDirect'