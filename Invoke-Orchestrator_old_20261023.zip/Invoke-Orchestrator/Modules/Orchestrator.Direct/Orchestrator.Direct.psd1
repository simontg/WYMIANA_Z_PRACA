@{
    RootModule        = 'Orchestrator.Direct.psm1'
    ModuleVersion     = '0.1.0'
    GUID              = 'd91e42b4-9df7-4e87-89ae-bbce1af26f5b'
    Author            = '<name-or-team>'
    CompanyName       = 'Knauf'
    Copyright         = '(c) Knauf. All rights reserved.'
    PowerShellVersion = '5.1'

    FunctionsToExport = @(
        'Invoke-OrchestratorDirect'
    )

    VariablesToExport = @()
    AliasesToExport   = @()
}