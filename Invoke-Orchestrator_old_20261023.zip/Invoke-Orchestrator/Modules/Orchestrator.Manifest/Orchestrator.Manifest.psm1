Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function New-OrchestratorManifestRow {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$RunId,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$JobName,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$Target,

        [Parameter(Mandatory)]
        [ValidateSet('Direct', 'ScheduledTask')]
        [string]$ExecutionEngine,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$RemoteFolder,

        [Parameter(Mandatory)]
        [ValidateSet(
            'Pending',
            'Preflight',
            'ConnectionFailed',
            'Deploying',
            'Running',
            'Collecting',
            'Completed',
            'Failed',
            'ContractMissing',
            'Stopped',
            'ConnectionLost',
            'CleanedUp'
        )]
        [string]$InitialStatus
    )

    [pscustomobject]@{
        RunId           = $RunId
        JobName         = $JobName
        Target          = $Target
        Status          = $InitialStatus
        Stage           = 'Preparation'
        ExecutionEngine = $ExecutionEngine
        RemoteFolder    = $RemoteFolder
        RemoteRunFolder = ''
        TaskName        = ''
        StartedUtc      = ''
        FinishedUtc     = ''
        ResultFile      = ''
        OutputFiles     = ''
        CleanupStatus   = 'NotStarted'
        ErrorMessage    = ''
    }
}

function Save-OrchestratorManifest {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [AllowEmptyCollection()]
        [object[]]$Rows,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$Path
    )

    $ParentFolder = Split-Path `
        -Path $Path `
        -Parent

    if (-not (Test-Path `
        -LiteralPath $ParentFolder `
        -PathType Container)) {

        New-Item `
            -Path $ParentFolder `
            -ItemType Directory `
            -Force `
            -ErrorAction Stop | Out-Null
    }

    $TemporaryPath = "$Path.tmp"

    try {
        $Rows |
            Export-Csv `
                -LiteralPath $TemporaryPath `
                -NoTypeInformation `
                -Encoding UTF8 `
                -Force `
                -ErrorAction Stop

        Move-Item `
            -LiteralPath $TemporaryPath `
            -Destination $Path `
            -Force `
            -ErrorAction Stop
    }
    finally {
        if (Test-Path `
            -LiteralPath $TemporaryPath `
            -PathType Leaf) {

            Remove-Item `
                -LiteralPath $TemporaryPath `
                -Force `
                -ErrorAction SilentlyContinue
        }
    }
}

Export-ModuleMember -Function @(
    'New-OrchestratorManifestRow',
    'Save-OrchestratorManifest'
)