@{
    RootModule        = 'Orchestrator.Manifest.psm1'
    ModuleVersion     = '0.1.0'
    GUID              = '9df1c1b2-3f3a-42e4-87cf-c22a50bf6f07'
    Author            = '<name-or-team>'
    CompanyName       = 'Knauf'
    Copyright         = '(c) Knauf. All rights reserved.'
    PowerShellVersion = '5.1'

    FunctionsToExport = @(
        'New-OrchestratorManifestRow',
        'Save-OrchestratorManifest'
    )

    VariablesToExport = @()
    AliasesToExport   = @()
}