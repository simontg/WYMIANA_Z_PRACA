#Requires -Version 5.1

<#
.SYNOPSIS
    Creates a simple test result for the Orchestrator.

.DESCRIPTION
    Writes a small result file and a contract file for testing the
    Orchestrator deployment and result collection process.

.PARAMETER ExampleValue
    Specifies a test value.

.PARAMETER Count
    Specifies the number of records to create.

.PARAMETER Force
    Specifies whether the test should overwrite existing output files.

.EXAMPLE
    .\Test-Example.ps1 `
        -ExampleValue 'Test' `
        -Count 1 `
        -Force

.NOTES
    Author: <name-or-team>
    Date: 2026-09-28
    Owner: <team-or-role>
    Environment: On-premises
    Domain or tenant: KNAUF.LOC / GROUP.KNAUF.LOC / TBD
    Requires: Windows PowerShell 5.1; no external modules
    Prerequisites / execution order:
        Must be executed from a directory where output files may be created.
    Change reference: <TBD>
    Known limitations: Test script only
    Last reviewed: 2026-09-28
    Status: Draft – not tested
    Version: 0.1.0
    Placement: Tools
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    [string]$ExampleValue,

    [Parameter(Mandatory)]
    [ValidateRange(1, 100)]
    [int]$Count,

    [Parameter()]
    [switch]$Force
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$StartedUtc = (Get-Date).ToUniversalTime()
$ResultPath = Join-Path -Path $PSScriptRoot -ChildPath 'ExampleResult.csv'
$LogPath = Join-Path -Path $PSScriptRoot -ChildPath 'Execution.log'
$ContractPath = Join-Path -Path $PSScriptRoot -ChildPath '_result.json'

try {
    $Rows = foreach ($Index in 1..$Count) {
        [pscustomobject]@{
            Index        = $Index
            ExampleValue = $ExampleValue
            ComputerName = $env:COMPUTERNAME
            TimestampUtc = (Get-Date).ToUniversalTime().ToString('o')
        }
    }

    if ($Force -or -not (Test-Path -LiteralPath $ResultPath)) {
        $Rows |
            Export-Csv `
                -LiteralPath $ResultPath `
                -NoTypeInformation `
                -Encoding UTF8 `
                -Force `
                -ErrorAction Stop
    }

    "Example script completed on '$env:COMPUTERNAME'." |
        Out-File `
            -LiteralPath $LogPath `
            -Encoding UTF8 `
            -Force `
            -ErrorAction Stop

    $FinishedUtc = (Get-Date).ToUniversalTime()

    [pscustomobject]@{
        ContractVersion = '1.0'
        Success         = $true
        Status          = 'Completed'
        OutputFiles     = @(
            'ExampleResult.csv',
            'Execution.log'
        )
        Error           = $null
        Message         = 'Example script completed successfully.'
        StartedUtc      = $StartedUtc.ToString('o')
        FinishedUtc     = $FinishedUtc.ToString('o')
    } |
        ConvertTo-Json -Depth 5 |
        Out-File `
            -LiteralPath $ContractPath `
            -Encoding UTF8 `
            -Force `
            -ErrorAction Stop
}
catch {
    $FinishedUtc = (Get-Date).ToUniversalTime()

    [pscustomobject]@{
        ContractVersion = '1.0'
        Success         = $false
        Status          = 'Failed'
        OutputFiles     = @(
            'Execution.log'
        )
        Error           = $_.Exception.Message
        Message         = 'Example script failed.'
        StartedUtc      = $StartedUtc.ToString('o')
        FinishedUtc     = $FinishedUtc.ToString('o')
    } |
        ConvertTo-Json -Depth 5 |
        Out-File `
            -LiteralPath $ContractPath `
            -Encoding UTF8 `
            -Force `
            -ErrorAction Stop

    throw
}