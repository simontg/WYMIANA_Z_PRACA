#Requires -Version 5.1

<#
.SYNOPSIS
    Tests DR subnet isolation from a production host.

.DESCRIPTION
    Runs from a production member server or domain controller and tests
    connectivity to the isolated DR host.

    The script tests TCP and UDP ports used by member servers, domain
    controllers, remote management, and approved Rubrik traffic.

    The script supports the Orchestrator result contract. It writes:
    - a CSV report;
    - a transcript log;
    - an _result.json result marker.

    All output files are written below the script directory so that the
    Orchestrator can collect them from the remote working folder.

.PARAMETER TargetIP
    Specifies the IP address of the isolated DR host.

.PARAMETER Label
    Specifies the label identifying this production vantage point.
    The default is the local computer name.

.PARAMETER Role
    Specifies the machine role to imitate: Auto, MemberServer, or DomainController.

.PARAMETER Method
    Specifies the TCP test method: Socket or TestNetConnection.

.PARAMETER TraceRoute
    Runs a traceroute to the isolated DR host.

.PARAMETER TimeoutMs
    Specifies the TCP and UDP timeout in milliseconds.

.PARAMETER FastFailSeconds
    Specifies the threshold used to distinguish a fast TCP refusal from
    a probable firewall timeout.

.PARAMETER PacketsPerPort
    Specifies the number of UDP packets sent per tested port.

.EXAMPLE
    .\Test-DRIsolation-ProductionHost.ps1 -Label 'DC-LOK-B'

.EXAMPLE
    .\Test-DRIsolation-ProductionHost.ps1 -Label 'DC-LOK-B' -Role DomainController -TraceRoute

.NOTES
    Author: <name-or-team>
    Date: 2026-09-29
    Owner: <team-or-role>
    Environment: On-premises
    Domain or tenant: KNAUF.LOC / GROUP.KNAUF.LOC / TBD
    Requires: Windows PowerShell 5.1; no external modules
    Prerequisites / execution order:
        Run from a production member server or domain controller.
        Start the listener on the isolated DR host before execution.
        The script must be allowed to create CSV, LOG, and JSON files below
        its own script directory.
    Change reference: <TBD>
    Known limitations:
        UDP results require confirmation in the listener log.
        PASS-WEAK means no UDP response was received and requires listener confirmation.
    Last reviewed: 2026-09-29
    Status: Draft – not tested
    Version: 0.1.0
    Placement: OnPrem/Infra
#>

[CmdletBinding()]
param(
    [Parameter()]
    [ValidatePattern('^(?:(?:25[0-5]|2[0-4][0-9]|1?[0-9]?[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1?[0-9]?[0-9])$')]
    [string]$TargetIP = '10.214.5.134',

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string]$Label = $env:COMPUTERNAME,

    [Parameter()]
    [ValidateSet('Auto', 'MemberServer', 'DomainController')]
    [string]$Role = 'Auto',

    [Parameter()]
    [ValidateSet('Socket', 'TestNetConnection')]
    [string]$Method = 'Socket',

    [Parameter()]
    [switch]$TraceRoute,

    [Parameter()]
    [ValidateRange(100, 60000)]
    [int]$TimeoutMs = 1500,

    [Parameter()]
    [ValidateRange(0.1, 60.0)]
    [double]$FastFailSeconds = 3.0,

    [Parameter()]
    [ValidateRange(1, 100)]
    [int]$PacketsPerPort = 5
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$MemberTcp = @(
    @{ Port = 53;   Purpose = 'DNS' }
    @{ Port = 88;   Purpose = 'Kerberos logon' }
    @{ Port = 135;  Purpose = 'RPC Endpoint Mapper' }
    @{ Port = 389;  Purpose = 'LDAP directory queries' }
    @{ Port = 445;  Purpose = 'SMB - SYSVOL, Group Policy, netlogon share' }
    @{ Port = 464;  Purpose = 'Kerberos password change' }
    @{ Port = 636;  Purpose = 'LDAP over SSL' }
    @{ Port = 3268; Purpose = 'Global Catalog' }
    @{ Port = 3269; Purpose = 'Global Catalog over SSL' }
)

$MemberUdp = @(
    @{ Port = 53;  Purpose = 'DNS' }
    @{ Port = 88;  Purpose = 'Kerberos logon' }
    @{ Port = 123; Purpose = 'W32Time / NTP' }
    @{ Port = 389; Purpose = 'LDAP / CLDAP (DC Locator)' }
    @{ Port = 464; Purpose = 'Kerberos password change' }
)

$ReplTcp = @(
    @{ Port = 139;   Purpose = 'NetBIOS Session Service' }
    @{ Port = 593;   Purpose = 'RPC over HTTP' }
    @{ Port = 9389;  Purpose = 'AD Web Services' }
    @{ Port = 49152; Purpose = 'Dynamic RPC - LSA/SAM/NetLogon, FRS, DFSR (low)' }
    @{ Port = 57343; Purpose = 'Dynamic RPC - mid' }
    @{ Port = 65535; Purpose = 'Dynamic RPC - top' }
)

$ReplUdp = @(
    @{ Port = 137; Purpose = 'NetBIOS Name Service' }
    @{ Port = 138; Purpose = 'NetBIOS Datagram Service' }
)

$MgmtTcp = @(
    @{ Port = 3389; Purpose = 'RDP' }
    @{ Port = 5985; Purpose = 'WinRM HTTP' }
    @{ Port = 5986; Purpose = 'WinRM HTTPS' }
)

$RubrikTcp = @(
    @{ Port = 12800; Purpose = 'Rubrik data' }
    @{ Port = 12801; Purpose = 'Rubrik data' }
)

$ApprovedInTcp = @(53, 88, 389, 445, 464, 636, 3268, 3269, 12800, 12801)
$ApprovedInUdp = @(53, 88, 137, 138, 139, 389, 464)

$ApprovedPeerIPs = @(
    '10.206.8.17','10.206.8.18','10.206.8.19','10.206.8.21','10.206.8.22','10.206.8.23',
    '10.206.8.24','10.206.8.25','10.206.8.26','10.206.8.31','10.206.8.33','10.206.8.34',
    '10.206.8.35','10.206.8.36','10.206.8.38','10.206.8.40','10.206.8.65','10.206.8.74',
    '10.206.8.78','10.206.8.79','10.206.8.94','10.206.8.98','10.206.8.100','10.206.8.101',
    '10.206.8.103','10.206.8.104','10.206.8.105','10.206.8.106','10.206.8.107','10.206.8.108',
    '10.206.8.109','10.206.8.110','10.206.8.112','10.206.8.113','10.206.8.114','10.206.8.115',
    '10.206.8.116','10.206.8.117','10.206.8.119','10.206.8.121','10.206.8.122','10.206.8.124',
    '10.206.8.125','10.206.8.126','10.206.8.127','10.206.8.128','10.206.8.129','10.206.8.130',
    '10.206.8.132','10.206.8.133','10.206.8.134','10.206.8.135','10.206.8.137','10.206.8.138',
    '10.206.8.139','10.206.8.143','10.206.8.145','10.206.8.146','10.206.8.153','10.206.8.154',
    '10.206.8.155','10.206.8.156','10.206.8.157','10.206.8.158','10.206.8.159','10.206.8.161',
    '10.206.8.163','10.206.8.165'
)

function Test-TcpSocket {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$IP,

        [Parameter(Mandatory)]
        [int]$Port,

        [Parameter(Mandatory)]
        [int]$Timeout
    )

    $Stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
    $TcpClient = $null
    $IsOpen = $false

    try {
        $TcpClient = New-Object System.Net.Sockets.TcpClient
        $AsyncResult = $TcpClient.BeginConnect($IP, $Port, $null, $null)

        if ($AsyncResult.AsyncWaitHandle.WaitOne($Timeout)) {
            try {
                $TcpClient.EndConnect($AsyncResult)
                $IsOpen = $TcpClient.Connected
            }
            catch {
                $IsOpen = $false
            }
        }
    }
    catch {
        $IsOpen = $false
    }
    finally {
        if ($null -ne $TcpClient) {
            $TcpClient.Close()
        }

        $Stopwatch.Stop()
    }

    [pscustomobject]@{
        Open      = [bool]$IsOpen
        Seconds   = [math]::Round($Stopwatch.Elapsed.TotalSeconds, 2)
        Source    = ''
        Interface = ''
    }
}

function Test-TcpConnection {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$IP,

        [Parameter(Mandatory)]
        [int]$Port
    )

    $Stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
    $TestResult = $null

    try {
        $TestResult = Test-NetConnection `
            -ComputerName $IP `
            -Port $Port `
            -InformationLevel Detailed `
            -WarningAction SilentlyContinue `
            -ErrorAction Stop
    }
    catch {
        $TestResult = $null
    }
    finally {
        $Stopwatch.Stop()
    }

    $IsOpen = $false
    $SourceAddress = ''
    $InterfaceAlias = ''

    if ($null -ne $TestResult) {
        $IsOpen = [bool]$TestResult.TcpTestSucceeded
        $InterfaceAlias = [string]$TestResult.InterfaceAlias

        if ($null -ne $TestResult.SourceAddress) {
            $SourceAddress = [string]$TestResult.SourceAddress.IPAddress
        }
    }

    [pscustomobject]@{
        Open      = $IsOpen
        Seconds   = [math]::Round($Stopwatch.Elapsed.TotalSeconds, 2)
        Source    = $SourceAddress
        Interface = $InterfaceAlias
    }
}

function Send-UdpProbe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$IP,

        [Parameter(Mandatory)]
        [int]$Port,

        [Parameter(Mandatory)]
        [int]$Timeout,

        [Parameter(Mandatory)]
        [string]$Payload
    )

    $UdpClient = $null

    try {
        $UdpClient = New-Object System.Net.Sockets.UdpClient
        $UdpClient.Client.ReceiveTimeout = $Timeout
        $UdpClient.Connect($IP, $Port)

        $Bytes = [System.Text.Encoding]::ASCII.GetBytes($Payload)
        [void]$UdpClient.Send($Bytes, $Bytes.Length)

        $Endpoint = New-Object System.Net.IPEndPoint([System.Net.IPAddress]::Any, 0)
        [void]$UdpClient.Receive([ref]$Endpoint)

        return $true
    }
    catch [System.Net.Sockets.SocketException] {
        if ($_.Exception.SocketErrorCode -eq [System.Net.Sockets.SocketError]::ConnectionReset) {
            return $false
        }

        return $null
    }
    catch {
        return $null
    }
    finally {
        if ($null -ne $UdpClient) {
            $UdpClient.Close()
        }
    }
}

function Get-VerdictColour {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Verdict
    )

    switch ($Verdict) {
        'PASS' { return 'Green' }
        'PASS-WEAK' { return 'DarkGreen' }
        'BREACH' { return 'Red' }
        'NO-ANSWER' { return 'Yellow' }
        default { return 'Gray' }
    }
}

function Write-TestHeader {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Title
    )

    Write-Host ''
    Write-Host '=================================================================' -ForegroundColor Cyan
    Write-Host " $Title" -ForegroundColor Cyan
    Write-Host '=================================================================' -ForegroundColor Cyan
}

function Write-OrchestratorResult {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [bool]$Success,

        [Parameter(Mandatory)]
        [ValidateSet('Completed', 'Failed')]
        [string]$Status,

        [Parameter(Mandatory)]
        [string[]]$OutputFiles,

        [Parameter()]
        [AllowNull()]
        [string]$ErrorMessage,

        [Parameter(Mandatory)]
        [string]$Message,

        [Parameter(Mandatory)]
        [datetime]$StartedUtc,

        [Parameter(Mandatory)]
        [datetime]$FinishedUtc,

        [Parameter(Mandatory)]
        [string]$Path
    )

    [pscustomobject]@{
        ContractVersion = '1.0'
        Success         = $Success
        Status          = $Status
        OutputFiles     = @($OutputFiles)
        Error           = $ErrorMessage
        Message         = $Message
        StartedUtc      = $StartedUtc.ToString('o')
        FinishedUtc     = $FinishedUtc.ToString('o')
    } |
        ConvertTo-Json -Depth 5 |
        Out-File -LiteralPath $Path -Encoding UTF8 -Force -ErrorAction Stop
}

$StartedUtc = (Get-Date).ToUniversalTime()
$Stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$SafeLabel = $Label -replace '[^A-Za-z0-9_-]', '_'
$RunId = 'RUN-{0}' -f (Get-Random -Minimum 100000 -Maximum 999999)

$WorkDir = $PSScriptRoot
$ReportPath = Join-Path -Path $WorkDir -ChildPath "DRIso_Prod_${SafeLabel}_$Stamp.csv"
$TranscriptPath = Join-Path -Path $WorkDir -ChildPath "DRIso_Prod_${SafeLabel}_$Stamp.log"
$ContractPath = Join-Path -Path $WorkDir -ChildPath '_result.json'

$OutputFiles = @(
    (Split-Path -Path $ReportPath -Leaf),
    (Split-Path -Path $TranscriptPath -Leaf)
)

$TranscriptStarted = $false

try {
    try {
        Start-Transcript -Path $TranscriptPath -ErrorAction Stop | Out-Null
        $TranscriptStarted = $true
    }
    catch {
        Write-Warning "Transcript unavailable: $($_.Exception.Message)"
    }

    $LocalIPs = @(
        Get-CimInstance -ClassName Win32_NetworkAdapterConfiguration -ErrorAction SilentlyContinue |
            Where-Object { $_.IPEnabled } |
            ForEach-Object { $_.IPAddress } |
            Where-Object { $_ -and $_ -notmatch ':' }
    )

    $IsRealDomainController = $false

    try {
        $OperatingSystem = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction Stop
        $IsRealDomainController = ($OperatingSystem.ProductType -eq 2)
    }
    catch {
        Write-Warning "Unable to determine local server role. Error: $($_.Exception.Message)"
    }

    if ($Role -ne 'Auto') {
        $EffectiveProfile = $Role
    }
    elseif ($IsRealDomainController) {
        $EffectiveProfile = 'DomainController'
    }
    else {
        $EffectiveProfile = 'MemberServer'
    }

    $MatchedApprovedIPs = @($LocalIPs | Where-Object { $ApprovedPeerIPs -contains $_ })
    $IsApprovedPeer = $MatchedApprovedIPs.Count -gt 0

    $TcpSet = @()
    $UdpSet = @()

    $TcpSet += $MemberTcp
    $UdpSet += $MemberUdp

    if ($EffectiveProfile -eq 'DomainController') {
        $TcpSet += $ReplTcp
        $UdpSet += $ReplUdp
    }

    $TcpSet += $MgmtTcp
    $TcpSet += $RubrikTcp

    $DcText = if ($IsRealDomainController) { 'yes' } else { 'no' }
    $AutoText = if ($Role -eq 'Auto') { ' (auto)' } else { '' }

    Write-TestHeader -Title 'DR ISOLATION - PRODUCTION SIDE'
    Write-Host " Target (DR host) : $TargetIP"
    Write-Host " This host        : $Label"
    Write-Host " Local IPs        : $($LocalIPs -join ', ')"
    Write-Host " Detected as DC   : $DcText"
    Write-Host " Imitating        : $EffectiveProfile$AutoText" -ForegroundColor Cyan
    Write-Host " Method           : $Method (UDP always raw socket)"
    Write-Host " Run ID           : $RunId" -ForegroundColor Yellow
    Write-Host " Local time       : $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
    Write-Host " UTC time         : $((Get-Date).ToUniversalTime().ToString('yyyy-MM-dd HH:mm:ss'))" -ForegroundColor Yellow
    Write-Host ''

    if ($IsApprovedPeer) {
        Write-Host " ROLE: APPROVED PEER ($($MatchedApprovedIPs -join ', '))" -ForegroundColor Green
        Write-Host ' This host IS on the approved firewall request.' -ForegroundColor DarkGray
        Write-Host ' The approved ports are expected to answer; everything else must still be blocked.' -ForegroundColor DarkGray
    }
    else {
        Write-Host ' ROLE: ORDINARY PRODUCTION - not on the approved list' -ForegroundColor Cyan
        Write-Host ' NOTHING should be reachable. Anything that answers is an isolation breach.' -ForegroundColor DarkGray
    }

    Write-Host ''
    Write-Host ' Make sure the isolated host is running:' -ForegroundColor Yellow
    Write-Host '   .\Test-DRIsolation-IsolatedHost.ps1 -Mode Listen' -ForegroundColor Yellow
    Write-Host ' right now. If it is not, a clean result proves nothing.' -ForegroundColor Yellow
    Write-Host ''

    $PingSucceeded = [bool](Test-Connection -ComputerName $TargetIP -Count 2 -Quiet -ErrorAction SilentlyContinue)
    $PingText = if ($PingSucceeded) { 'replies (informational only)' } else { 'no reply' }

    Write-Host (" ICMP ping        : {0}" -f $PingText) -ForegroundColor DarkGray
    Write-Host ''

    $Results = @()

    Write-Host " TCP  ($($TcpSet.Count) ports)" -ForegroundColor Cyan

    foreach ($PortDefinition in $TcpSet) {
        if ($IsApprovedPeer -and ($ApprovedInTcp -contains $PortDefinition.Port)) {
            $ExpectedState = 'Open'
        }
        else {
            $ExpectedState = 'Closed'
        }

        if ($Method -eq 'TestNetConnection') {
            $TcpResult = Test-TcpConnection -IP $TargetIP -Port $PortDefinition.Port
        }
        else {
            $TcpResult = Test-TcpSocket -IP $TargetIP -Port $PortDefinition.Port -Timeout $TimeoutMs
        }

        if ($TcpResult.Open) {
            $State = 'OPEN'
            $Why = 'Port answered - service listening, path open'
        }
        elseif ($TcpResult.Seconds -lt $FastFailSeconds) {
            $State = 'REFUSED'
            $Why = "Fast failure ($($TcpResult.Seconds)s, RST) - host reachable, nothing listening"
        }
        else {
            $State = 'TIMEOUT'
            $Why = "Slow failure ($($TcpResult.Seconds)s) - dropped silently, looks like a firewall block"
        }

        if ($State -eq 'OPEN') {
            $Verdict = if ($ExpectedState -eq 'Open') { 'PASS' } else { 'BREACH' }
        }
        else {
            $Verdict = if ($ExpectedState -eq 'Closed') { 'PASS' } else { 'NO-ANSWER' }
        }

        Write-Host (
            '   {0,-6} {1,-48} [{2,-9}] {3,-8} {4}s' -f `
                $PortDefinition.Port,
                $PortDefinition.Purpose,
                $Verdict,
                $State,
                $TcpResult.Seconds
        ) -ForegroundColor (Get-VerdictColour -Verdict $Verdict)

        $Results += [pscustomobject]@{
            RunId            = $RunId
            VantagePoint     = $Label
            ImitatingProfile = $EffectiveProfile
            IsApprovedPeer   = $IsApprovedPeer
            SourceIPs        = $LocalIPs -join ';'
            TargetIP         = $TargetIP
            Port             = $PortDefinition.Port
            Protocol         = 'TCP'
            Purpose          = $PortDefinition.Purpose
            Expected         = $ExpectedState
            State            = $State
            Verdict          = $Verdict
            Seconds          = $TcpResult.Seconds
            Why              = $Why
            SourceIP         = $TcpResult.Source
            Interface        = $TcpResult.Interface
            Method           = $Method
            TestedAt         = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
            TestedAtUtc      = (Get-Date).ToUniversalTime().ToString('yyyy-MM-dd HH:mm:ss')
        }
    }

    Write-Host ''
    Write-Host " UDP  ($($UdpSet.Count) ports, $PacketsPerPort packets each - verdict is read on the listener, Run ID $RunId)" -ForegroundColor Cyan

    foreach ($PortDefinition in $UdpSet) {
        if ($IsApprovedPeer -and ($ApprovedInUdp -contains $PortDefinition.Port)) {
            $ExpectedState = 'Open'
        }
        else {
            $ExpectedState = 'Closed'
        }

        $Outcomes = @()

        for ($Sequence = 1; $Sequence -le $PacketsPerPort; $Sequence++) {
            $Payload = "ISOLATION-PROBE|$RunId|from=$Label|profile=$EffectiveProfile|port=$($PortDefinition.Port)|seq=$Sequence|$(Get-Date -Format 'HH:mm:ss')"
            $Outcomes += ,(Send-UdpProbe -IP $TargetIP -Port $PortDefinition.Port -Timeout $TimeoutMs -Payload $Payload)
            Start-Sleep -Milliseconds 120
        }

        $ReplyCount = @($Outcomes | Where-Object { $_ -eq $true }).Count
        $UnreachableCount = @($Outcomes | Where-Object { $_ -eq $false }).Count

        if ($ReplyCount -gt 0) {
            $State = 'OPEN'
            $Why = "Reply on $ReplyCount/$PacketsPerPort packets"
            $Verdict = if ($ExpectedState -eq 'Open') { 'PASS' } else { 'BREACH' }
        }
        elseif ($UnreachableCount -gt 0) {
            $State = 'REFUSED'
            $Why = 'ICMP Port Unreachable - packets reached the host'
            $Verdict = if ($ExpectedState -eq 'Open') { 'NO-ANSWER' } else { 'BREACH' }
        }
        else {
            $State = 'SILENT'
            $Why = 'No response - check the listener log for the Run ID'
            $Verdict = if ($ExpectedState -eq 'Open') { 'NO-ANSWER' } else { 'PASS-WEAK' }
        }

        Write-Host (
            '   {0,-6} {1,-48} [{2,-9}] {3,-8} {4}' -f `
                $PortDefinition.Port,
                $PortDefinition.Purpose,
                $Verdict,
                $State,
                $Why
        ) -ForegroundColor (Get-VerdictColour -Verdict $Verdict)

        $Results += [pscustomobject]@{
            RunId            = $RunId
            VantagePoint     = $Label
            ImitatingProfile = $EffectiveProfile
            IsApprovedPeer   = $IsApprovedPeer
            SourceIPs        = $LocalIPs -join ';'
            TargetIP         = $TargetIP
            Port             = $PortDefinition.Port
            Protocol         = 'UDP'
            Purpose          = $PortDefinition.Purpose
            Expected         = $ExpectedState
            State            = $State
            Verdict          = $Verdict
            Seconds          = $null
            Why              = "$Why (sent $PacketsPerPort)"
            SourceIP         = ''
            Interface        = ''
            Method           = 'Socket(UDP)'
            TestedAt         = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
            TestedAtUtc      = (Get-Date).ToUniversalTime().ToString('yyyy-MM-dd HH:mm:ss')
        }
    }

    if ($TraceRoute) {
        Write-Host ''
        Write-Host " TraceRoute to $TargetIP ..." -ForegroundColor Cyan -NoNewline

        try {
            $TraceResult = Test-NetConnection -ComputerName $TargetIP -TraceRoute -Hops 20 -WarningAction SilentlyContinue -ErrorAction Stop

            if ($TraceResult.TraceRoute) {
                $TraceRouteText = $TraceResult.TraceRoute -join ' > '
            }
            else {
                $TraceRouteText = '(no route returned)'
            }
        }
        catch {
            $TraceRouteText = "traceroute failed: $($_.Exception.Message)"
        }

        Write-Host ' done' -ForegroundColor Cyan
        Write-Host "   $TraceRouteText" -ForegroundColor DarkGray
        Write-Host ''
    }

    $Results |
        Export-Csv -LiteralPath $ReportPath -NoTypeInformation -Encoding UTF8 -Force -ErrorAction Stop

    $BreachResults = @($Results | Where-Object { $_.Verdict -eq 'BREACH' })
    $NoAnswerResults = @($Results | Where-Object { $_.Verdict -eq 'NO-ANSWER' })
    $PassResults = @($Results | Where-Object { $_.Verdict -in @('PASS', 'PASS-WEAK') })

    Write-TestHeader -Title "RESULT - $Label (imitating $EffectiveProfile)"

    Write-Host (
        ' Tests: {0}   As expected: {1}   BREACHES: {2}   No answer: {3}' -f `
            $Results.Count,
            $PassResults.Count,
            $BreachResults.Count,
            $NoAnswerResults.Count
    )

    Write-Host ''

    if ($BreachResults.Count -gt 0) {
        Write-Host ' *** ISOLATION BREACH ***' -ForegroundColor Red
        Write-Host ' This host reached the DR host on ports it must not:' -ForegroundColor Red

        foreach ($Breach in $BreachResults) {
            Write-Host (
                '   {0}/{1}  {2}  [{3}]' -f `
                    $Breach.Port,
                    $Breach.Protocol,
                    $Breach.Purpose,
                    $Breach.State
            ) -ForegroundColor Red
        }

        Write-Host ''
        Write-Host ' ACTION: do NOT promote the DR host to a Domain Controller.' -ForegroundColor Red
        Write-Host ' Send this CSV together with the listener CSV from the isolated host.' -ForegroundColor Red
    }
    elseif ($NoAnswerResults.Count -gt 0) {
        Write-Host ' APPROVED PORTS WITH NO ANSWER' -ForegroundColor Yellow

        foreach ($NoAnswer in $NoAnswerResults) {
            Write-Host (
                '   {0}/{1}  {2}  [{3}]' -f `
                    $NoAnswer.Port,
                    $NoAnswer.Protocol,
                    $NoAnswer.Purpose,
                    $NoAnswer.State
            ) -ForegroundColor Yellow
        }

        Write-Host ''
        Write-Host ' Confirm that the listener was running and bound to those ports.' -ForegroundColor Yellow
    }
    else {
        if ($IsApprovedPeer) {
            Write-Host ' Approved ports answered, everything else blocked - exactly right.' -ForegroundColor Green
        }
        else {
            Write-Host ' Nothing was reachable from this host. Isolation is holding.' -ForegroundColor Green
        }
    }

    Write-Host ''
    Write-Host " NEXT: on $TargetIP check the listener log for Run ID $RunId" -ForegroundColor Cyan

    if ($IsApprovedPeer) {
        Write-Host '   present on approved ports -> the approved UDP rules work' -ForegroundColor Cyan
        Write-Host '   absent -> the approved UDP rules do NOT work' -ForegroundColor Cyan
    }
    else {
        Write-Host '   absent -> UDP never arrived, isolation confirmed' -ForegroundColor Cyan
        Write-Host '   present -> UDP got through, ISOLATION BREACH' -ForegroundColor Cyan
    }

    Write-Host ''
    Write-Host " CSV report : $ReportPath"
    Write-Host " Transcript : $TranscriptPath"
    Write-Host " Contract   : $ContractPath"
    Write-Host ''

    $FinishedUtc = (Get-Date).ToUniversalTime()

    $OutputFiles += Split-Path -Path $ContractPath -Leaf

    if ($BreachResults.Count -eq 0) {
        $ContractSuccess = $true
        $ContractStatus = 'Completed'
        $ContractError = $null
        $ContractMessage = 'DR isolation test completed.'
    }
    else {
        $ContractSuccess = $false
        $ContractStatus = 'Failed'
        $ContractError = 'Isolation breach detected.'
        $ContractMessage = 'DR isolation test completed with isolation breach.'
    }

    Write-OrchestratorResult `
        -Success $ContractSuccess `
        -Status $ContractStatus `
        -OutputFiles $OutputFiles `
        -ErrorMessage $ContractError `
        -Message $ContractMessage `
        -StartedUtc $StartedUtc `
        -FinishedUtc $FinishedUtc `
        -Path $ContractPath
}
catch {
    $FinishedUtc = (Get-Date).ToUniversalTime()
    $ErrorMessage = $_.Exception.Message

    try {
        $FailureOutputFiles = @()

        if (Test-Path -LiteralPath $ReportPath -PathType Leaf) {
            $FailureOutputFiles += Split-Path -Path $ReportPath -Leaf
        }

        if (Test-Path -LiteralPath $TranscriptPath -PathType Leaf) {
            $FailureOutputFiles += Split-Path -Path $TranscriptPath -Leaf
        }

        Write-OrchestratorResult `
            -Success $false `
            -Status 'Failed' `
            -OutputFiles $FailureOutputFiles `
            -ErrorMessage $ErrorMessage `
            -Message 'DR isolation test failed.' `
            -StartedUtc $StartedUtc `
            -FinishedUtc $FinishedUtc `
            -Path $ContractPath
    }
    catch {
        Write-Warning "Unable to write Orchestrator result contract. Error: $($_.Exception.Message)"
    }

    throw
}
finally {
    if ($TranscriptStarted) {
        try {
            Stop-Transcript -ErrorAction SilentlyContinue | Out-Null
        }
        catch {
            Write-Verbose 'Stop-Transcript did not complete.'
        }
    }
}