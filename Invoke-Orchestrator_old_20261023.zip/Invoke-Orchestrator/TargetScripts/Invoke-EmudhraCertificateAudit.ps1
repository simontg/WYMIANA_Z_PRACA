#Requires -Version 5.1

<#
.SYNOPSIS
    Audits local machine certificate stores for selected eMudhra-related certificate indicators.

.DESCRIPTION
    Runs locally on the audited Windows server. The script is designed for direct local execution
    or delivery through Invoke-Orchestrator Direct mode.

    It audits selected LocalMachine certificate stores for exact CN matches against known
    compromised eMudhra intermediate CA names and selected legal/root names used for context.

    The script writes:
    - _result.json for Orchestrator collection;
    - summary CSV;
    - details CSV;
    - optional execution transcript log.

.PARAMETER IncludeExecutionLog
    Writes a PowerShell transcript log beside the script output files.

.EXAMPLE
    .\Invoke-EmudhraCertificateAudit.ps1 -Verbose

.NOTES
    Author: <name-or-team>
    Date: 2026-10-21
    Owner: <team-or-role>
    Environment: On-premises
    Domain or tenant: KNAUF.LOC / GROUP.KNAUF.LOC / TBD
    Requires: Windows PowerShell 5.1; no external modules
    Prerequisites / execution order:
        Run locally on the audited server, or deliver through Orchestrator Direct.
        The execution account needs read access to LocalMachine certificate stores.
    Change reference: <TBD>
    Known limitations:
        Audits LocalMachine certificate stores only.
        Does not inspect CurrentUser stores, application-specific trust stores,
        browser stores, Linux hosts, network appliances, or file-based trust stores.
        Does not prove active exploitation or malware infection.
        Does not remediate findings.
        Private-key certificate chain analysis is conservative and checks the private-key
        certificate Subject and Issuer only; it does not call .NET X509Chain.
    Last reviewed: 2026-10-23
    Status: Draft – not tested
    Version: 0.1.1
    Placement: OnPrem/PKI
#>

[CmdletBinding()]
param(
    [Parameter()]
    [switch]$IncludeExecutionLog = $true
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$ScriptStartUtc = (Get-Date).ToUniversalTime()
$Timestamp = $ScriptStartUtc.ToString('yyyyMMddTHHmmssZ')
$ComputerName = $env:COMPUTERNAME

$OutputRoot = $PSScriptRoot
$SummaryCsvPath = Join-Path -Path $OutputRoot -ChildPath "EmudhraCertificateAudit-Summary-$Timestamp.csv"
$DetailsCsvPath = Join-Path -Path $OutputRoot -ChildPath "EmudhraCertificateAudit-Details-$Timestamp.csv"
$ContractPath = Join-Path -Path $OutputRoot -ChildPath '_result.json'
$LogPath = Join-Path -Path $OutputRoot -ChildPath "EmudhraCertificateAudit-Execution-$Timestamp.log"

$TranscriptStarted = $false

$CompromisedCertificateNames = @(
    'EM DV TLS CA - G3B',
    'EM DV TLS CA - G3C',
    'EM EV TLS CA - G3B',
    'EM EV TLS CA - G3C',
    'EM OV TLS CA - G3B',
    'EM OV TLS CA - G3C',
    'EM OV CS CA - G3B',
    'EM OV CS CA - G3C'
)

$LegalRootNames = @(
    'AAA Certificate Services',
    'emSign ECC Root CA - G3'
)

$StoreNames = @(
    'My',
    'Root',
    'CA',
    'AuthRoot',
    'TrustedPublisher',
    'Disallowed'
)

$SummaryColumns = @(
    'RecordType',
    'ComputerName',
    'OverallStatus',
    'OSVersion',
    'OSBuild',
    'IsCertificateAuthority',
    'CertSvcStatus',
    'CompromisedMatchCount',
    'MatchedCertificateNames',
    'MatchedStores',
    'PrivateKeyMatchCount',
    'LegalRootMatchCount',
    'LegalRootNames',
    'Errors',
    'RecommendedAction',
    'ScanStart',
    'ScanEnd'
)

$DetailsColumns = @(
    'RecordType',
    'ComputerName',
    'Store',
    'Subject',
    'Issuer',
    'FriendlyName',
    'Thumbprint',
    'SerialNumber',
    'NotBefore',
    'NotAfter',
    'HasPrivateKey',
    'BasicConstraints',
    'EnhancedKeyUsage',
    'MatchType',
    'MatchedName',
    'MatchedField',
    'FindingSource',
    'ChainLeafThumbprint',
    'RecommendedAction'
)

function ConvertTo-JoinedText {
    [CmdletBinding()]
    param(
        [Parameter()]
        [AllowNull()]
        [object[]]$Value
    )

    $Items = @(
        $Value |
            Where-Object { $null -ne $_ -and -not [string]::IsNullOrWhiteSpace([string]$_) } |
            ForEach-Object { [string]$_ }
    )

    if ($Items.Count -eq 0) {
        return $null
    }

    return ($Items -join '; ')
}

function Export-CsvWithColumns {
    [CmdletBinding()]
    param(
        [Parameter()]
        [AllowNull()]
        [AllowEmptyCollection()]
        [object[]]$InputObject,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string[]]$Columns,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$Path
    )

    $Rows = @($InputObject)

    if ($Rows.Count -eq 0) {
        $Header = ($Columns | ForEach-Object { '"' + ($_ -replace '"', '""') + '"' }) -join ','
        Set-Content -LiteralPath $Path -Value $Header -Encoding UTF8 -Force
        return
    }

    $Rows |
        Select-Object -Property $Columns |
        Export-Csv -LiteralPath $Path -NoTypeInformation -Encoding UTF8 -Force
}

function Get-ExactCertificateNameMatch {
    [CmdletBinding()]
    param(
        [Parameter()]
        [AllowNull()]
        [string]$DistinguishedName,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string[]]$CandidateNames
    )

    if ([string]::IsNullOrWhiteSpace($DistinguishedName)) {
        return $null
    }

    foreach ($CandidateName in $CandidateNames) {
        $EscapedName = [regex]::Escape($CandidateName)
        $CnPattern = "(?i)(?:^|,)\s*CN\s*=\s*$EscapedName\s*(?=,|$)"

        if ($DistinguishedName -match $CnPattern) {
            return $CandidateName
        }

        if ($DistinguishedName.Trim() -ieq $CandidateName) {
            return $CandidateName
        }
    }

    return $null
}

function Get-CertificateExtensionText {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [System.Security.Cryptography.X509Certificates.X509Certificate2]$Certificate,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$OidValue
    )

    $Extension = $Certificate.Extensions |
        Where-Object { $_.Oid.Value -eq $OidValue } |
        Select-Object -First 1

    if ($null -eq $Extension) {
        return $null
    }

    try {
        return ($Extension.Format($true) -replace "(`r`n|`n|`r)", '; ')
    }
    catch {
        return $Extension.Oid.FriendlyName
    }
}

function Get-CertificateHasPrivateKey {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [System.Security.Cryptography.X509Certificates.X509Certificate2]$Certificate
    )

    try {
        return [bool]$Certificate.HasPrivateKey
    }
    catch {
        return $false
    }
}

function New-CertificateFinding {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$ComputerName,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$Store,

        [Parameter(Mandatory)]
        [System.Security.Cryptography.X509Certificates.X509Certificate2]$Certificate,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$MatchType,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$MatchedName,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$MatchedField,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$FindingSource,

        [Parameter()]
        [AllowNull()]
        [string]$ChainLeafThumbprint
    )

    $RecommendedAction = switch ($MatchType) {
        'EXACT_COMPROMISED_INTERMEDIATE' {
            'Investigate certificate use and affected service or application. Replace affected certificates as appropriate, apply approved trust-store updates, and re-run the audit. Do not automatically remove root certificates.'
        }

        'EXACT_COMPROMISED_INTERMEDIATE_IN_CHAIN' {
            'Investigate the private-key certificate and its consuming service or application. Replace affected certificates as appropriate, apply approved trust-store updates, and re-run the audit. Do not automatically remove root certificates.'
        }

        'LEGAL_SECTIGO_ROOT_PRESENT' {
            'No removal action based on this finding alone. This root is reported for context only.'
        }

        default {
            'Review the finding.'
        }
    }

    [pscustomobject]@{
        RecordType          = 'CertificateFinding'
        ComputerName        = $ComputerName
        Store               = $Store
        Subject             = $Certificate.Subject
        Issuer              = $Certificate.Issuer
        FriendlyName        = $Certificate.FriendlyName
        Thumbprint          = $Certificate.Thumbprint
        SerialNumber        = $Certificate.SerialNumber
        NotBefore           = $Certificate.NotBefore.ToUniversalTime().ToString('o')
        NotAfter            = $Certificate.NotAfter.ToUniversalTime().ToString('o')
        HasPrivateKey       = Get-CertificateHasPrivateKey -Certificate $Certificate
        BasicConstraints    = Get-CertificateExtensionText -Certificate $Certificate -OidValue '2.5.29.19'
        EnhancedKeyUsage    = Get-CertificateExtensionText -Certificate $Certificate -OidValue '2.5.29.37'
        MatchType           = $MatchType
        MatchedName         = $MatchedName
        MatchedField        = $MatchedField
        FindingSource       = $FindingSource
        ChainLeafThumbprint = $ChainLeafThumbprint
        RecommendedAction   = $RecommendedAction
    }
}

function Get-PrivateKeyCertificateFindings {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [System.Security.Cryptography.X509Certificates.X509Certificate2]$Certificate,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$ComputerName
    )

    $Results = @()

    $SubjectCompromisedMatch = Get-ExactCertificateNameMatch `
        -DistinguishedName $Certificate.Subject `
        -CandidateNames $CompromisedCertificateNames

    if ($SubjectCompromisedMatch) {
        $Results += New-CertificateFinding `
            -ComputerName $ComputerName `
            -Certificate $Certificate `
            -Store 'LocalMachine\My' `
            -MatchType 'EXACT_COMPROMISED_INTERMEDIATE_IN_CHAIN' `
            -MatchedName $SubjectCompromisedMatch `
            -MatchedField 'PrivateKeyCertificateSubject' `
            -FindingSource 'PrivateKeyCertificate' `
            -ChainLeafThumbprint $Certificate.Thumbprint
    }

    $IssuerCompromisedMatch = Get-ExactCertificateNameMatch `
        -DistinguishedName $Certificate.Issuer `
        -CandidateNames $CompromisedCertificateNames

    if ($IssuerCompromisedMatch) {
        $Results += New-CertificateFinding `
            -ComputerName $ComputerName `
            -Certificate $Certificate `
            -Store 'LocalMachine\My' `
            -MatchType 'EXACT_COMPROMISED_INTERMEDIATE_IN_CHAIN' `
            -MatchedName $IssuerCompromisedMatch `
            -MatchedField 'PrivateKeyCertificateIssuer' `
            -FindingSource 'PrivateKeyCertificate' `
            -ChainLeafThumbprint $Certificate.Thumbprint
    }

    return @($Results)
}

function New-AuditSummary {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$ComputerName,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$OverallStatus,

        [Parameter()]
        [AllowNull()]
        [object]$OperatingSystem,

        [Parameter(Mandatory)]
        [bool]$IsCertificateAuthority,

        [Parameter()]
        [AllowNull()]
        [string]$CertSvcStatus,

        [Parameter()]
        [AllowEmptyCollection()]
        [object[]]$CompromisedFindings,

        [Parameter()]
        [AllowEmptyCollection()]
        [object[]]$LegalRootFindings,

        [Parameter()]
        [AllowEmptyCollection()]
        [string[]]$Errors,

        [Parameter(Mandatory)]
        [int]$PrivateKeyMatchCount,

        [Parameter(Mandatory)]
        [datetime]$ScanStart,

        [Parameter(Mandatory)]
        [datetime]$ScanEnd
    )

    $MatchedCertificateNames = @(
        $CompromisedFindings |
            Select-Object -ExpandProperty MatchedName -Unique
    )

    $MatchedStores = @(
        $CompromisedFindings |
            Select-Object -ExpandProperty Store -Unique
    )

    $MatchedLegalRootNames = @(
        $LegalRootFindings |
            Select-Object -ExpandProperty MatchedName -Unique
    )

    $RecommendedAction = switch ($OverallStatus) {
        'DIRECT_MATCH' {
            'Urgent analysis required. Investigate matched certificates, affected services, and trust-store state. Replace affected certificates as appropriate, apply approved trust-store updates, and re-run the audit.'
        }

        'CLEAN_WITH_LIMITATIONS' {
            'No compromised certificate match was found, but one or more stores or metadata checks had errors. Review Errors and re-run if required.'
        }

        'CLEAN' {
            'No compromised certificate match was found in audited LocalMachine stores.'
        }

        default {
            'Review audit result.'
        }
    }

    [pscustomobject]@{
        RecordType                 = 'Summary'
        ComputerName               = $ComputerName
        OverallStatus              = $OverallStatus
        OSVersion                  = if ($null -ne $OperatingSystem) { [string]$OperatingSystem.Caption } else { $null }
        OSBuild                    = if ($null -ne $OperatingSystem) { [string]$OperatingSystem.BuildNumber } else { $null }
        IsCertificateAuthority     = $IsCertificateAuthority
        CertSvcStatus              = $CertSvcStatus
        CompromisedMatchCount      = @($CompromisedFindings).Count
        MatchedCertificateNames    = ConvertTo-JoinedText -Value $MatchedCertificateNames
        MatchedStores              = ConvertTo-JoinedText -Value $MatchedStores
        PrivateKeyMatchCount       = $PrivateKeyMatchCount
        LegalRootMatchCount        = @($LegalRootFindings).Count
        LegalRootNames             = ConvertTo-JoinedText -Value $MatchedLegalRootNames
        Errors                     = ConvertTo-JoinedText -Value $Errors
        RecommendedAction          = $RecommendedAction
        ScanStart                  = $ScanStart.ToUniversalTime().ToString('o')
        ScanEnd                    = $ScanEnd.ToUniversalTime().ToString('o')
    }
}

function Write-OrchestratorResult {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [bool]$Success,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$Status,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$Message,

        [Parameter()]
        [AllowNull()]
        [string]$ErrorMessage,

        [Parameter()]
        [AllowEmptyCollection()]
        [string[]]$OutputFiles,

        [Parameter(Mandatory)]
        [datetime]$StartedUtc,

        [Parameter(Mandatory)]
        [datetime]$FinishedUtc,

        [Parameter()]
        [hashtable]$AdditionalData
    )

    $Result = [ordered]@{
        ContractVersion = '1.0'
        Success         = $Success
        Status          = $Status
        OutputFiles     = @($OutputFiles)
        Error           = $ErrorMessage
        Message         = $Message
        StartedUtc      = $StartedUtc.ToUniversalTime().ToString('o')
        FinishedUtc     = $FinishedUtc.ToUniversalTime().ToString('o')
    }

    if ($AdditionalData) {
        foreach ($Key in $AdditionalData.Keys) {
            $Result[$Key] = $AdditionalData[$Key]
        }
    }

    [pscustomobject]$Result |
        ConvertTo-Json -Depth 8 |
        Out-File -LiteralPath $ContractPath -Encoding UTF8 -Force
}

$Errors = @()
$Findings = @()
$PrivateKeyMatchCount = 0
$IsCertificateAuthority = $false
$CertSvcStatus = $null
$OperatingSystem = $null
$Summary = $null

try {
    if ($IncludeExecutionLog) {
        try {
            Start-Transcript -Path $LogPath -ErrorAction Stop | Out-Null
            $TranscriptStarted = $true
        }
        catch {
            Write-Warning "Unable to start transcript. Error: $($_.Exception.Message)"
        }
    }

    Write-Verbose "Starting local eMudhra certificate audit on '$ComputerName'."

    try {
        $OperatingSystem = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction Stop
    }
    catch {
        $Errors += "Unable to read operating system information. $($_.Exception.Message)"
    }

    try {
        $CertificateService = Get-Service -Name 'CertSvc' -ErrorAction SilentlyContinue

        if ($null -ne $CertificateService) {
            $IsCertificateAuthority = $true
            $CertSvcStatus = [string]$CertificateService.Status
        }
    }
    catch {
        $Errors += "Unable to inspect CertSvc service. $($_.Exception.Message)"
    }

    foreach ($StoreName in $StoreNames) {
        $StorePath = "Cert:\LocalMachine\$StoreName"

        Write-Verbose "Auditing certificate store '$StorePath'."

        try {
            if (-not (Test-Path -Path $StorePath)) {
                $Errors += "Certificate store is unavailable: $StorePath"
                continue
            }

            $Certificates = @(
                Get-ChildItem -Path $StorePath -ErrorAction Stop
            )

            foreach ($Certificate in $Certificates) {
                $SubjectCompromisedMatch = Get-ExactCertificateNameMatch `
                    -DistinguishedName $Certificate.Subject `
                    -CandidateNames $CompromisedCertificateNames

                if ($SubjectCompromisedMatch) {
                    $Findings += New-CertificateFinding `
                        -ComputerName $ComputerName `
                        -Certificate $Certificate `
                        -Store "LocalMachine\$StoreName" `
                        -MatchType 'EXACT_COMPROMISED_INTERMEDIATE' `
                        -MatchedName $SubjectCompromisedMatch `
                        -MatchedField 'Subject' `
                        -FindingSource 'CertificateStore' `
                        -ChainLeafThumbprint $null
                }

                $IssuerCompromisedMatch = Get-ExactCertificateNameMatch `
                    -DistinguishedName $Certificate.Issuer `
                    -CandidateNames $CompromisedCertificateNames

                if ($IssuerCompromisedMatch) {
                    $Findings += New-CertificateFinding `
                        -ComputerName $ComputerName `
                        -Certificate $Certificate `
                        -Store "LocalMachine\$StoreName" `
                        -MatchType 'EXACT_COMPROMISED_INTERMEDIATE' `
                        -MatchedName $IssuerCompromisedMatch `
                        -MatchedField 'Issuer' `
                        -FindingSource 'CertificateStore' `
                        -ChainLeafThumbprint $null
                }

                $LegalRootSubjectMatch = Get-ExactCertificateNameMatch `
                    -DistinguishedName $Certificate.Subject `
                    -CandidateNames $LegalRootNames

                if ($LegalRootSubjectMatch) {
                    $Findings += New-CertificateFinding `
                        -ComputerName $ComputerName `
                        -Certificate $Certificate `
                        -Store "LocalMachine\$StoreName" `
                        -MatchType 'LEGAL_SECTIGO_ROOT_PRESENT' `
                        -MatchedName $LegalRootSubjectMatch `
                        -MatchedField 'Subject' `
                        -FindingSource 'CertificateStore' `
                        -ChainLeafThumbprint $null
                }

                if ($StoreName -eq 'My' -and (Get-CertificateHasPrivateKey -Certificate $Certificate)) {
                    $PrivateKeyFindings = @(
                        Get-PrivateKeyCertificateFindings `
                            -Certificate $Certificate `
                            -ComputerName $ComputerName
                    )

                    foreach ($PrivateKeyFinding in $PrivateKeyFindings) {
                        if ($PrivateKeyFinding.MatchType -eq 'EXACT_COMPROMISED_INTERMEDIATE_IN_CHAIN') {
                            $PrivateKeyMatchCount++
                        }

                        $Findings += $PrivateKeyFinding
                    }
                }
            }
        }
        catch {
            $Errors += "Unable to audit store '$StorePath'. $($_.Exception.Message)"
        }
    }

    $CompromisedFindings = @(
        $Findings |
            Where-Object {
                $_.MatchType -in @(
                    'EXACT_COMPROMISED_INTERMEDIATE',
                    'EXACT_COMPROMISED_INTERMEDIATE_IN_CHAIN'
                )
            }
    )

    $LegalRootFindings = @(
        $Findings |
            Where-Object { $_.MatchType -eq 'LEGAL_SECTIGO_ROOT_PRESENT' }
    )

    if ($CompromisedFindings.Count -gt 0) {
        $OverallStatus = 'DIRECT_MATCH'
    }
    elseif ($Errors.Count -gt 0) {
        $OverallStatus = 'CLEAN_WITH_LIMITATIONS'
    }
    else {
        $OverallStatus = 'CLEAN'
    }

    $ScriptEndUtc = (Get-Date).ToUniversalTime()

    $Summary = New-AuditSummary `
        -ComputerName $ComputerName `
        -OverallStatus $OverallStatus `
        -OperatingSystem $OperatingSystem `
        -IsCertificateAuthority $IsCertificateAuthority `
        -CertSvcStatus $CertSvcStatus `
        -CompromisedFindings $CompromisedFindings `
        -LegalRootFindings $LegalRootFindings `
        -Errors $Errors `
        -PrivateKeyMatchCount $PrivateKeyMatchCount `
        -ScanStart $ScriptStartUtc `
        -ScanEnd $ScriptEndUtc

    Export-CsvWithColumns -InputObject @($Summary) -Columns $SummaryColumns -Path $SummaryCsvPath
    Export-CsvWithColumns -InputObject @($Findings) -Columns $DetailsColumns -Path $DetailsCsvPath

    $OutputFiles = @(
        Split-Path -Path $SummaryCsvPath -Leaf
        Split-Path -Path $DetailsCsvPath -Leaf
    )

    if ($IncludeExecutionLog) {
        $OutputFiles += Split-Path -Path $LogPath -Leaf
    }

    $OutputFiles += '_result.json'

    Write-OrchestratorResult `
        -Success $true `
        -Status $OverallStatus `
        -Message "eMudhra audit completed with status '$OverallStatus'." `
        -ErrorMessage $null `
        -OutputFiles $OutputFiles `
        -StartedUtc $ScriptStartUtc `
        -FinishedUtc $ScriptEndUtc `
        -AdditionalData @{
            ComputerName                = $ComputerName
            OverallStatus               = $OverallStatus
            CompromisedMatchCount       = $CompromisedFindings.Count
            PrivateKeyMatchCount        = $PrivateKeyMatchCount
            LegalRootMatchCount         = $LegalRootFindings.Count
            UrgentAnalysisRequired      = ($OverallStatus -eq 'DIRECT_MATCH')
            CompletedWithLimitations    = ($OverallStatus -eq 'CLEAN_WITH_LIMITATIONS')
            IsCertificateAuthority      = $IsCertificateAuthority
            CertSvcStatus               = $CertSvcStatus
        }

    $Summary
}
catch {
    $FatalErrorMessage = $_.Exception.Message
    $ScriptEndUtc = (Get-Date).ToUniversalTime()

    try {
        $FailureSummary = [pscustomobject]@{
            RecordType                 = 'Summary'
            ComputerName               = $ComputerName
            OverallStatus              = 'ERROR'
            OSVersion                  = if ($null -ne $OperatingSystem) { [string]$OperatingSystem.Caption } else { $null }
            OSBuild                    = if ($null -ne $OperatingSystem) { [string]$OperatingSystem.BuildNumber } else { $null }
            IsCertificateAuthority     = $IsCertificateAuthority
            CertSvcStatus              = $CertSvcStatus
            CompromisedMatchCount      = 0
            MatchedCertificateNames    = $null
            MatchedStores              = $null
            PrivateKeyMatchCount       = $PrivateKeyMatchCount
            LegalRootMatchCount        = 0
            LegalRootNames             = $null
            Errors                     = $FatalErrorMessage
            RecommendedAction          = 'Review the execution log, fix the script or environment issue, and re-run the audit.'
            ScanStart                  = $ScriptStartUtc.ToUniversalTime().ToString('o')
            ScanEnd                    = $ScriptEndUtc.ToUniversalTime().ToString('o')
        }

        Export-CsvWithColumns -InputObject @($FailureSummary) -Columns $SummaryColumns -Path $SummaryCsvPath
        Export-CsvWithColumns -InputObject @($Findings) -Columns $DetailsColumns -Path $DetailsCsvPath

        $OutputFiles = @(
            Split-Path -Path $SummaryCsvPath -Leaf
            Split-Path -Path $DetailsCsvPath -Leaf
        )

        if ($IncludeExecutionLog) {
            $OutputFiles += Split-Path -Path $LogPath -Leaf
        }

        $OutputFiles += '_result.json'

        Write-OrchestratorResult `
            -Success $false `
            -Status 'ERROR' `
            -Message 'eMudhra audit failed before a reliable result could be produced.' `
            -ErrorMessage $FatalErrorMessage `
            -OutputFiles $OutputFiles `
            -StartedUtc $ScriptStartUtc `
            -FinishedUtc $ScriptEndUtc `
            -AdditionalData @{
                ComputerName             = $ComputerName
                OverallStatus            = 'ERROR'
                CompromisedMatchCount    = 0
                PrivateKeyMatchCount     = $PrivateKeyMatchCount
                LegalRootMatchCount      = 0
                UrgentAnalysisRequired   = $false
                CompletedWithLimitations = $true
                IsCertificateAuthority   = $IsCertificateAuthority
                CertSvcStatus            = $CertSvcStatus
            }

        $FailureSummary
    }
    catch {
        Write-Warning "Unable to write failure output. Error: $($_.Exception.Message)"
    }
}
finally {
    if ($TranscriptStarted) {
        try {
            Stop-Transcript | Out-Null
        }
        catch {
            Write-Warning "Unable to stop transcript. Error: $($_.Exception.Message)"
        }
    }
}