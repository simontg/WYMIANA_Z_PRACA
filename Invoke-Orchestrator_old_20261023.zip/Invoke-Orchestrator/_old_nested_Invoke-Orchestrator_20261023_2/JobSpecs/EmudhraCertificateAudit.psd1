@{
    JobName = 'EmudhraCertificateAudit'

    ScriptPath = '..\TargetScripts\Invoke-EmudhraCertificateAudit.ps1'

    Targets = @(
        'SERVER01',
        'SERVER02',
        'SERVER03'
    )

    Parameters = @{
    }

    ExecutionEngine = 'Direct'
    RemoteFolder    = 'C:\temp'
    ThrottleLimit   = 10
    TimeoutMinutes  = 30
    OutputFolder    = 'C:\Users\T0_GmerekS\TOOLS\Orchestrator-EmudhraAudit\Output'
    CleanupMode     = 'OnSuccess'
}