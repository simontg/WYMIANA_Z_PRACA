#Requires -Version 5.1

<#
.SYNOPSIS
    Audits the local Windows server for compromised eMudhra intermediate CA certificates.

.DESCRIPTION
    Runs locally on the audited server. This script is designed to be delivered
    and executed by the Orchestrator in Direct mode.

    The script is read-only. It does not remove certificates, add certificates,
    modify registry settings, modify GPO, change services, install updates, or
    modify PKI configuration.

    The script audits these LocalMachine certificate stores:

    - Cert:\LocalMachine\My
    - Cert:\LocalMachine\Root
    - Cert:\LocalMachine\CA
    - Cert:\LocalMachine\AuthRoot
    - Cert:\LocalMachine\TrustedPublisher
    - Cert:\LocalMachine\Disallowed

    It also builds certificate chains for certificates with HasPrivateKey = True
    in Cert:\LocalMachine\My.

    The script detects the eight compromised eMudhra intermediate CA names and
    records legal root CA presence separately. Legal root CA presence does not
    cause DIRECT_MATCH.

    Output files are written to the script directory so that the Orchestrator can
    collect them from its remote working folder.

.PARAMETER IncludeExecutionLog
    Writes an execution transcript log beside the CSV files.

.EXAMPLE
    .\Invoke-EmudhraCertificateAudit.ps1 -Verbose

.NOTES
    Author: <name-or-team>
    Date: 2026-10-21
    Owner: <team-or-role>
    Environment: On-premises
    Domain or tenant: KNAUF.LOC / GROUP.KNAUF.LOC / TBD
    Requires: Windows PowerShell 5.1; no external modules
    Prerequisites / execution order:
        Run locally on the audited server, or deliver through Orchestrator Direct.
        The execution account needs read access to LocalMachine certificate stores.
    Change reference: <TBD>
    Known limitations:
        Audits LocalMachine certificate stores only.
        Does not inspect CurrentUser stores, application-specific trust stores,
        browser stores, Linux hosts, network appliances, or file-based trust stores.
        Does not prove active exploitation or malware infection.
        Does not remediate findings.
    Last reviewed: 2026-10-21
    Status: Draft – not tested
    Version: 0.1.0
    Placement: OnPrem/PKI
#>

[CmdletBinding()]
param(
    [Parameter()]
    [switch]$IncludeExecutionLog = $true
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$ScriptStartUtc = (Get-Date).ToUniversalTime()
$Timestamp = $ScriptStartUtc.ToString('yyyyMMddTHHmmssZ')
$ComputerName = $env:COMPUTERNAME

$OutputRoot = $PSScriptRoot
$SummaryCsvPath = Join-Path -Path $OutputRoot -ChildPath "EmudhraCertificateAudit-Summary-$Timestamp.csv"
$DetailsCsvPath = Join-Path -Path $OutputRoot -ChildPath "EmudhraCertificateAudit-Details-$Timestamp.csv"
$ContractPath = Join-Path -Path $OutputRoot -ChildPath '_result.json'
$LogPath = Join-Path -Path $OutputRoot -ChildPath "EmudhraCertificateAudit-Execution-$Timestamp.log"

$TranscriptStarted = $false

$CompromisedCertificateNames = @(
    'EM DV TLS CA - G3B',
    'EM DV TLS CA - G3C',
    'EM EV TLS CA - G3B',
    'EM EV TLS CA - G3C',
    'EM OV TLS CA - G3B',
    'EM OV TLS CA - G3C',
    'EM OV CS CA - G3B',
    'EM OV CS CA - G3C'
)

$LegalRootNames = @(
    'AAA Certificate Services',
    'emSign ECC Root CA - G3'
)

$StoreNames = @(
    'My',
    'Root',
    'CA',
    'AuthRoot',
    'TrustedPublisher',
    'Disallowed'
)

$SummaryColumns = @(
    'RecordType',
    'ComputerName',
    'OverallStatus',
    'OSVersion',
    'OSBuild',
    'IsCertificateAuthority',
    'CertSvcStatus',
    'CompromisedMatchCount',
    'MatchedCertificateNames',
    'MatchedStores',
    'PrivateKeyMatchCount',
    'LegalRootMatchCount',
    'LegalRootNames',
    'Errors',
    'RecommendedAction',
    'ScanStart',
    'ScanEnd'
)

$DetailColumns = @(
    'RecordType',
    'ComputerName',
    'Store',
    'Subject',
    'Issuer',
    'FriendlyName',
    'Thumbprint',
    'SerialNumber',
    'NotBefore',
    'NotAfter',
    'HasPrivateKey',
    'BasicConstraints',
    'EnhancedKeyUsage',
    'MatchType',
    'MatchedName',
    'MatchedField',
    'FindingSource',
    'ChainLeafThumbprint',
    'RecommendedAction'
)

function Get-ExactCertificateNameMatch {
    [CmdletBinding()]
    param(
        [Parameter()]
        [AllowNull()]
        [string]$DistinguishedName,

        [Parameter(Mandatory)]
        [string[]]$CandidateNames
    )

    if ([string]::IsNullOrWhiteSpace($DistinguishedName)) {
        return $null
    }

    foreach ($CandidateName in $CandidateNames) {
        $EscapedName = [regex]::Escape($CandidateName)
        $Pattern = "(?i)(?:^|,)\s*CN\s*=\s*$EscapedName\s*(?=,|$)"

        if ($DistinguishedName -match $Pattern) {
            return $CandidateName
        }
    }

    return $null
}

function Get-CertificateExtensionText {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [System.Security.Cryptography.X509Certificates.X509Certificate2]$Certificate,

        [Parameter(Mandatory)]
        [string]$OidValue
    )

    $Extension = $Certificate.Extensions |
        Where-Object {
            $_.Oid.Value -eq $OidValue
        } |
        Select-Object -First 1

    if ($null -eq $Extension) {
        return ''
    }

    try {
        return $Extension.Format($true)
    }
    catch {
        return ''
    }
}

function New-CertificateFinding {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [System.Security.Cryptography.X509Certificates.X509Certificate2]$Certificate,

        [Parameter(Mandatory)]
        [string]$Store,

        [Parameter(Mandatory)]
        [ValidateSet(
            'EXACT_COMPROMISED_INTERMEDIATE',
            'EXACT_COMPROMISED_INTERMEDIATE_IN_CHAIN',
            'LEGAL_SECTIGO_ROOT_PRESENT'
        )]
        [string]$MatchType,

        [Parameter(Mandatory)]
        [string]$MatchedName,

        [Parameter(Mandatory)]
        [ValidateSet('Subject', 'Issuer', 'ChainSubject', 'ChainIssuer')]
        [string]$MatchedField,

        [Parameter(Mandatory)]
        [string]$FindingSource,

        [Parameter()]
        [AllowNull()]
        [string]$ChainLeafThumbprint
    )

    $BasicConstraints = Get-CertificateExtensionText `
        -Certificate $Certificate `
        -OidValue '2.5.29.19'

    $EnhancedKeyUsage = Get-CertificateExtensionText `
        -Certificate $Certificate `
        -OidValue '2.5.29.37'

    $RecommendedAction = switch ($MatchType) {
        'EXACT_COMPROMISED_INTERMEDIATE' {
            'Urgent PKI/security analysis required. Do not remediate automatically.'
        }
        'EXACT_COMPROMISED_INTERMEDIATE_IN_CHAIN' {
            'Urgent PKI/security analysis required. Certificate chain references a compromised intermediate CA. Do not remediate automatically.'
        }
        'LEGAL_SECTIGO_ROOT_PRESENT' {
            'Informational only. Legal root CA presence is not a DIRECT_MATCH and is not a removal recommendation.'
        }
    }

    [pscustomobject]@{
        RecordType          = 'CertificateFinding'
        ComputerName        = $ComputerName
        Store               = $Store
        Subject             = $Certificate.Subject
        Issuer              = $Certificate.Issuer
        FriendlyName        = $Certificate.FriendlyName
        Thumbprint          = $Certificate.Thumbprint
        SerialNumber        = $Certificate.SerialNumber
        NotBefore           = $Certificate.NotBefore.ToUniversalTime().ToString('o')
        NotAfter            = $Certificate.NotAfter.ToUniversalTime().ToString('o')
        HasPrivateKey       = [bool]$Certificate.HasPrivateKey
        BasicConstraints    = $BasicConstraints
        EnhancedKeyUsage    = $EnhancedKeyUsage
        MatchType           = $MatchType
        MatchedName         = $MatchedName
        MatchedField        = $MatchedField
        FindingSource       = $FindingSource
        ChainLeafThumbprint = $ChainLeafThumbprint
        RecommendedAction   = $RecommendedAction
    }
}

function Export-CsvWithColumns {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [AllowEmptyCollection()]
        [object[]]$InputObject,

        [Parameter(Mandatory)]
        [string[]]$Columns,

        [Parameter(Mandatory)]
        [string]$Path
    )

    if ($InputObject.Count -gt 0) {
        $InputObject |
            Select-Object -Property $Columns |
            Export-Csv `
                -LiteralPath $Path `
                -NoTypeInformation `
                -Encoding UTF8 `
                -Force `
                -ErrorAction Stop

        return
    }

    $HeaderLine = ($Columns | ForEach-Object {
        '"' + ($_ -replace '"', '""') + '"'
    }) -join ','

    $HeaderLine |
        Out-File `
            -LiteralPath $Path `
            -Encoding UTF8 `
            -Force `
            -ErrorAction Stop
}

function Write-OrchestratorResult {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [bool]$Success,

        [Parameter(Mandatory)]
        [string]$Status,

        [Parameter(Mandatory)]
        [string[]]$OutputFiles,

        [Parameter()]
        [AllowNull()]
        [string]$ErrorMessage,

        [Parameter(Mandatory)]
        [string]$Message,

        [Parameter(Mandatory)]
        [datetime]$StartedUtc,

        [Parameter(Mandatory)]
        [datetime]$FinishedUtc,

        [Parameter()]
        [hashtable]$AdditionalData
    )

    $Result = [ordered]@{
        ContractVersion = '1.0'
        Success         = $Success
        Status          = $Status
        OutputFiles     = @($OutputFiles)
        Error           = $ErrorMessage
        Message         = $Message
        StartedUtc      = $StartedUtc.ToString('o')
        FinishedUtc     = $FinishedUtc.ToString('o')
    }

    if ($AdditionalData) {
        foreach ($Key in $AdditionalData.Keys) {
            $Result[$Key] = $AdditionalData[$Key]
        }
    }

    [pscustomobject]$Result |
        ConvertTo-Json -Depth 8 |
        Out-File `
            -LiteralPath $ContractPath `
            -Encoding UTF8 `
            -Force `
            -ErrorAction Stop
}

function Get-CertificateChainFindings {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [System.Security.Cryptography.X509Certificates.X509Certificate2]$LeafCertificate
    )

    $ChainFindings = New-Object System.Collections.Generic.List[object]
    $Chain = New-Object System.Security.Cryptography.X509Certificates.X509Chain

    $Chain.ChainPolicy.RevocationMode = [System.Security.Cryptography.X509Certificates.X509RevocationMode]::NoCheck
    $Chain.ChainPolicy.RevocationFlag = [System.Security.Cryptography.X509Certificates.X509RevocationFlag]::ExcludeRoot
    $Chain.ChainPolicy.VerificationFlags = [System.Security.Cryptography.X509Certificates.X509VerificationFlags]::AllFlags

    try {
        [void]$Chain.Build($LeafCertificate)

        foreach ($Element in $Chain.ChainElements) {
            $ChainCertificate = $Element.Certificate

            $SubjectCompromisedMatch = Get-ExactCertificateNameMatch `
                -DistinguishedName $ChainCertificate.Subject `
                -CandidateNames $CompromisedCertificateNames

            if ($SubjectCompromisedMatch) {
                $ChainFindings.Add(
                    (New-CertificateFinding `
                        -Certificate $ChainCertificate `
                        -Store 'LocalMachine\My chain' `
                        -MatchType 'EXACT_COMPROMISED_INTERMEDIATE_IN_CHAIN' `
                        -MatchedName $SubjectCompromisedMatch `
                        -MatchedField 'ChainSubject' `
                        -FindingSource 'PrivateKeyCertificateChain' `
                        -ChainLeafThumbprint $LeafCertificate.Thumbprint)
                )
            }

            $IssuerCompromisedMatch = Get-ExactCertificateNameMatch `
                -DistinguishedName $ChainCertificate.Issuer `
                -CandidateNames $CompromisedCertificateNames

            if ($IssuerCompromisedMatch) {
                $ChainFindings.Add(
                    (New-CertificateFinding `
                        -Certificate $ChainCertificate `
                        -Store 'LocalMachine\My chain' `
                        -MatchType 'EXACT_COMPROMISED_INTERMEDIATE_IN_CHAIN' `
                        -MatchedName $IssuerCompromisedMatch `
                        -MatchedField 'ChainIssuer' `
                        -FindingSource 'PrivateKeyCertificateChain' `
                        -ChainLeafThumbprint $LeafCertificate.Thumbprint)
                )
            }

            $LegalRootSubjectMatch = Get-ExactCertificateNameMatch `
                -DistinguishedName $ChainCertificate.Subject `
                -CandidateNames $LegalRootNames

            if ($LegalRootSubjectMatch) {
                $ChainFindings.Add(
                    (New-CertificateFinding `
                        -Certificate $ChainCertificate `
                        -Store 'LocalMachine\My chain' `
                        -MatchType 'LEGAL_SECTIGO_ROOT_PRESENT' `
                        -MatchedName $LegalRootSubjectMatch `
                        -MatchedField 'ChainSubject' `
                        -FindingSource 'PrivateKeyCertificateChain' `
                        -ChainLeafThumbprint $LeafCertificate.Thumbprint)
                )
            }
        }
    }
    finally {
        if ($null -ne $Chain) {
            $Chain.Reset()
        }
    }

    return @($ChainFindings)
}

$Errors = New-Object System.Collections.Generic.List[string]
$Findings = New-Object System.Collections.Generic.List[object]
$PrivateKeyMatchCount = 0
$IsCertificateAuthority = $false
$CertSvcStatus = $null
$OperatingSystem = $null
$Summary = $null

try {
    if ($IncludeExecutionLog) {
        try {
            Start-Transcript `
                -Path $LogPath `
                -ErrorAction Stop |
                Out-Null

            $TranscriptStarted = $true
        }
        catch {
            Write-Warning "Unable to start transcript. Error: $($_.Exception.Message)"
        }
    }

    Write-Verbose "Starting local eMudhra certificate audit on '$ComputerName'."

    try {
        $OperatingSystem = Get-CimInstance `
            -ClassName Win32_OperatingSystem `
            -ErrorAction Stop
    }
    catch {
        $Errors.Add("Unable to read operating system information. $($_.Exception.Message)")
    }

    try {
        $CertificateService = Get-Service `
            -Name 'CertSvc' `
            -ErrorAction SilentlyContinue

        if ($null -ne $CertificateService) {
            $IsCertificateAuthority = $true
            $CertSvcStatus = [string]$CertificateService.Status
        }
    }
    catch {
        $Errors.Add("Unable to inspect CertSvc service. $($_.Exception.Message)")
    }

    foreach ($StoreName in $StoreNames) {
        $StorePath = "Cert:\LocalMachine\$StoreName"

        Write-Verbose "Auditing certificate store '$StorePath'."

        try {
            if (-not (Test-Path -Path $StorePath)) {
                $Errors.Add("Certificate store is unavailable: $StorePath")
                continue
            }

            $Certificates = @(
                Get-ChildItem `
                    -Path $StorePath `
                    -ErrorAction Stop
            )

            foreach ($Certificate in $Certificates) {
                $SubjectCompromisedMatch = Get-ExactCertificateNameMatch `
                    -DistinguishedName $Certificate.Subject `
                    -CandidateNames $CompromisedCertificateNames

                if ($SubjectCompromisedMatch) {
                    $Findings.Add(
                        (New-CertificateFinding `
                            -Certificate $Certificate `
                            -Store "LocalMachine\$StoreName" `
                            -MatchType 'EXACT_COMPROMISED_INTERMEDIATE' `
                            -MatchedName $SubjectCompromisedMatch `
                            -MatchedField 'Subject' `
                            -FindingSource 'CertificateStore' `
                            -ChainLeafThumbprint $null)
                    )
                }

                $IssuerCompromisedMatch = Get-ExactCertificateNameMatch `
                    -DistinguishedName $Certificate.Issuer `
                    -CandidateNames $CompromisedCertificateNames

                if ($IssuerCompromisedMatch) {
                    $Findings.Add(
                        (New-CertificateFinding `
                            -Certificate $Certificate `
                            -Store "LocalMachine\$StoreName" `
                            -MatchType 'EXACT_COMPROMISED_INTERMEDIATE' `
                            -MatchedName $IssuerCompromisedMatch `
                            -MatchedField 'Issuer' `
                            -FindingSource 'CertificateStore' `
                            -ChainLeafThumbprint $null)
                    )
                }

                $LegalRootSubjectMatch = Get-ExactCertificateNameMatch `
                    -DistinguishedName $Certificate.Subject `
                    -CandidateNames $LegalRootNames

                if ($LegalRootSubjectMatch) {
                    $Findings.Add(
                        (New-CertificateFinding `
                            -Certificate $Certificate `
                            -Store "LocalMachine\$StoreName" `
                            -MatchType 'LEGAL_SECTIGO_ROOT_PRESENT' `
                            -MatchedName $LegalRootSubjectMatch `
                            -MatchedField 'Subject' `
                            -FindingSource 'CertificateStore' `
                            -ChainLeafThumbprint $null)
                    )
                }

                if ($StoreName -eq 'My' -and $Certificate.HasPrivateKey) {
                    try {
                        $ChainFindings = @(
                            Get-CertificateChainFindings `
                                -LeafCertificate $Certificate
                        )

                        foreach ($ChainFinding in $ChainFindings) {
                            if ($ChainFinding.MatchType -eq 'EXACT_COMPROMISED_INTERMEDIATE_IN_CHAIN') {
                                $PrivateKeyMatchCount++
                            }

                            $Findings.Add($ChainFinding)
                        }
                    }
                    catch {
                        $Errors.Add("Unable to build certificate chain for thumbprint '$($Certificate.Thumbprint)'. $($_.Exception.Message)")
                    }
                }
            }
        }
        catch {
            $Errors.Add("Unable to audit store '$StorePath'. $($_.Exception.Message)")
        }
    }

    $CompromisedFindings = @(
        $Findings |
            Where-Object {
                $_.MatchType -in @(
                    'EXACT_COMPROMISED_INTERMEDIATE',
                    'EXACT_COMPROMISED_INTERMEDIATE_IN_CHAIN'
                )
            }
    )

    $LegalRootFindings = @(
        $Findings |
            Where-Object {
                $_.MatchType -eq 'LEGAL_SECTIGO_ROOT_PRESENT'
            }
    )

    $MatchedCertificateNames = @(
        $CompromisedFindings |
            Select-Object -ExpandProperty MatchedName -Unique
    )

    $MatchedStores = @(
        $CompromisedFindings |
            Select-Object -ExpandProperty Store -Unique
    )

    $MatchedLegalRootNames = @(
        $LegalRootFindings |
            Select-Object -ExpandProperty MatchedName -Unique
    )

    if ($CompromisedFindings.Count -gt 0) {
        $OverallStatus = 'DIRECT_MATCH'
        $RecommendedAction = 'Urgent PKI/security analysis required. Do not remediate automatically.'
    }
    elseif ($Errors.Count -gt 0) {
        $OverallStatus = 'CLEAN_WITH_LIMITATIONS'
        $RecommendedAction = 'No compromised eMudhra intermediate CA match found, but some checks failed or were unavailable. Review Errors.'
    }
    else {
        $OverallStatus = 'CLEAN'
        $RecommendedAction = 'No compromised eMudhra intermediate CA match found in audited LocalMachine stores or private-key certificate chains.'
    }

    $ScanEndUtc = (Get-Date).ToUniversalTime()

    $Summary = [pscustomobject]@{
        RecordType                 = 'Summary'
        ComputerName               = $ComputerName
        OverallStatus              = $OverallStatus
        OSVersion                  = if ($null -ne $OperatingSystem) { [string]$OperatingSystem.Caption } else { $null }
        OSBuild                    = if ($null -ne $OperatingSystem) { [string]$OperatingSystem.BuildNumber } else { $null }
        IsCertificateAuthority     = $IsCertificateAuthority
        CertSvcStatus              = $CertSvcStatus
        CompromisedMatchCount      = $CompromisedFindings.Count
        MatchedCertificateNames    = $MatchedCertificateNames -join ';'
        MatchedStores              = $MatchedStores -join ';'
        PrivateKeyMatchCount       = $PrivateKeyMatchCount
        LegalRootMatchCount        = $LegalRootFindings.Count
        LegalRootNames             = $MatchedLegalRootNames -join ';'
        Errors                     = ($Errors.ToArray() -join ' | ')
        RecommendedAction          = $RecommendedAction
        ScanStart                  = $ScriptStartUtc.ToString('o')
        ScanEnd                    = $ScanEndUtc.ToString('o')
    }

    Export-CsvWithColumns `
        -InputObject @($Summary) `
        -Columns $SummaryColumns `
        -Path $SummaryCsvPath

    Export-CsvWithColumns `
        -InputObject @($Findings) `
        -Columns $DetailColumns `
        -Path $DetailsCsvPath

    $OutputFiles = @(
        Split-Path -Path $SummaryCsvPath -Leaf
        Split-Path -Path $DetailsCsvPath -Leaf
    )

    if ($IncludeExecutionLog -and (Test-Path -LiteralPath $LogPath -PathType Leaf)) {
        $OutputFiles += Split-Path -Path $LogPath -Leaf
    }

    $OutputFiles += Split-Path -Path $ContractPath -Leaf

    $UrgentAnalysisRequired = ($OverallStatus -eq 'DIRECT_MATCH')
    $CompletedWithLimitations = ($OverallStatus -in @('CLEAN_WITH_LIMITATIONS', 'ERROR', 'NOT_SCANNED'))

    $ContractMessage = if ($UrgentAnalysisRequired) {
        'eMudhra audit completed. DIRECT_MATCH detected. Urgent PKI/security analysis required.'
    }
    elseif ($CompletedWithLimitations) {
        'eMudhra audit completed with limitations.'
    }
    else {
        'eMudhra audit completed. No compromised eMudhra intermediate CA match detected.'
    }

    Write-OrchestratorResult `
        -Success $true `
        -Status 'Completed' `
        -OutputFiles $OutputFiles `
        -ErrorMessage $null `
        -Message $ContractMessage `
        -StartedUtc $ScriptStartUtc `
        -FinishedUtc $ScanEndUtc `
        -AdditionalData @{
            ComputerName              = $ComputerName
            OverallStatus             = $OverallStatus
            UrgentAnalysisRequired    = $UrgentAnalysisRequired
            CompletedWithLimitations  = $CompletedWithLimitations
            CompromisedMatchCount     = $CompromisedFindings.Count
            PrivateKeyMatchCount      = $PrivateKeyMatchCount
            LegalRootMatchCount       = $LegalRootFindings.Count
            SummaryCsv                = (Split-Path -Path $SummaryCsvPath -Leaf)
            DetailsCsv                = (Split-Path -Path $DetailsCsvPath -Leaf)
        }

    Write-Verbose "eMudhra certificate audit completed on '$ComputerName' with status '$OverallStatus'."

    $Summary
    $Findings
}
catch {
    $FailureEndUtc = (Get-Date).ToUniversalTime()
    $FailureMessage = $_.Exception.Message

    $FailureSummary = [pscustomobject]@{
        RecordType                 = 'Summary'
        ComputerName               = $ComputerName
        OverallStatus              = 'ERROR'
        OSVersion                  = $null
        OSBuild                    = $null
        IsCertificateAuthority     = $null
        CertSvcStatus              = $null
        CompromisedMatchCount      = 0
        MatchedCertificateNames    = $null
        MatchedStores              = $null
        PrivateKeyMatchCount       = 0
        LegalRootMatchCount        = 0
        LegalRootNames             = $null
        Errors                     = $FailureMessage
        RecommendedAction          = 'Audit failed. Review execution log and rerun the audit.'
        ScanStart                  = $ScriptStartUtc.ToString('o')
        ScanEnd                    = $FailureEndUtc.ToString('o')
    }

    try {
        Export-CsvWithColumns `
            -InputObject @($FailureSummary) `
            -Columns $SummaryColumns `
            -Path $SummaryCsvPath

        Export-CsvWithColumns `
            -InputObject @() `
            -Columns $DetailColumns `
            -Path $DetailsCsvPath

        $FailureOutputFiles = @(
            Split-Path -Path $SummaryCsvPath -Leaf
            Split-Path -Path $DetailsCsvPath -Leaf
        )

        if ($IncludeExecutionLog -and (Test-Path -LiteralPath $LogPath -PathType Leaf)) {
            $FailureOutputFiles += Split-Path -Path $LogPath -Leaf
        }

        $FailureOutputFiles += Split-Path -Path $ContractPath -Leaf

        Write-OrchestratorResult `
            -Success $false `
            -Status 'Failed' `
            -OutputFiles $FailureOutputFiles `
            -ErrorMessage $FailureMessage `
            -Message 'eMudhra audit failed before a reliable result could be produced.' `
            -StartedUtc $ScriptStartUtc `
            -FinishedUtc $FailureEndUtc `
            -AdditionalData @{
                ComputerName              = $ComputerName
                OverallStatus             = 'ERROR'
                UrgentAnalysisRequired    = $false
                CompletedWithLimitations  = $true
                CompromisedMatchCount     = 0
                PrivateKeyMatchCount      = 0
                LegalRootMatchCount       = 0
            }

        $FailureSummary
    }
    catch {
        Write-Warning "Unable to write failure output. Error: $($_.Exception.Message)"
    }

    
}
finally {
    if ($TranscriptStarted) {
        try {
            Stop-Transcript `
                -ErrorAction SilentlyContinue |
                Out-Null
        }
        catch {
            Write-Verbose 'Stop-Transcript did not complete.'
        }
    }
}